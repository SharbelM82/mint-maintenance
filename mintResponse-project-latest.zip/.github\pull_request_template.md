## Requested change
Identify the owner's explicit instruction and the affected section.

## Public wording and formatting
List every changed string and visual change. No unrelated changes are permitted.

## Checks
Record npm run verify results, desktop/mobile preview review and form success/failure tests. State any checks that were not completed.

## Publication
Owner review is required before merging to main. A connected Cloudflare production branch can publish on merge.

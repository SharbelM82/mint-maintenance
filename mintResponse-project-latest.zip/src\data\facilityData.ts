import { ServiceDetail } from '../types';

export const COMPANY_INFO = {
  name: 'Mint Response',
  tagline: 'Your Trusted Commercial Facility Management Partner',
  motto: 'Fast Response. Professional Service. Lasting Solutions.',
  location: '581 Coconut Lane, Centerton, AR, 72719',
  stateCoverage: 'Serving Commercial Properties',
  phonePlaceholder: '+1 (479) 341-5787',
  phoneDisplay: '+1 (479) 341-5787',
  phoneHref: '+14793415787',
  email: 'info@mintresponse.com',
  businessHours: 'Monday – Sunday 8 am to 5 pm CT',
  emergencyNotice: 'Emergency service availability upon request.',
  heroDescription:
    'Mint Response provides reliable commercial maintenance and facility solutions. We help businesses maintain safe, efficient, and professional environments through expert HVAC, plumbing, electrical, handyman, and renovation services.',
  welcomeTitle: 'Welcome to Mint Response',
  welcomeParagraph1:
    'At Mint Response, we understand that every commercial property depends on properly functioning systems to keep operations running smoothly. Whether you manage an office building, retail center, warehouse, healthcare facility, restaurant, or industrial property, our team is committed to delivering dependable maintenance and repair services when you need them most.',
  welcomeParagraph2:
    'We focus exclusively on commercial properties, providing quality workmanship, responsive service, and customized solutions to help protect your investment and minimize downtime.',
  aboutDescription1:
    'Mint Response is an Arkansas-based facility management and maintenance company dedicated to serving commercial properties throughout the region.',
  aboutDescription2:
    'Founded with a commitment to professionalism, responsiveness, and quality workmanship, we help businesses maintain safe, efficient, and productive facilities. Our team works closely with property managers, facility managers, business owners, and commercial tenants to provide dependable maintenance and improvement solutions.',
  goalStatement: 'Keep Your Facility Operating at Its Best.',
  aboutClosing:
    'As a growing company, we are focused on building long-term relationships through outstanding service, clear communication, and dependable results.',
  mission:
    'To provide commercial clients with reliable facility maintenance and repair solutions that enhance safety, efficiency, and business continuity.',
  vision:
    'To become a trusted facility management partner for businesses throughout the region by delivering responsive service and exceptional value.',
};

export const WHY_CHOOSE_US = [
  {
    title: 'Responsive Service',
    description: 'We prioritize quick response times to help keep your business operational.',
    metric: 'Rapid Dispatch',
    highlight: 'Minimized facility downtime',
  },
  {
    title: 'Commercial Expertise',
    description: 'Our services are tailored specifically for commercial facilities and business environments.',
    metric: 'Commercial Only',
    highlight: 'Building code compliance',
  },
  {
    title: 'Reliable Solutions',
    description: 'We focus on practical, cost-effective repairs and maintenance that support long-term performance.',
    metric: 'Lasting Results',
    highlight: 'Preventive lifecycle care',
  },
  {
    title: 'One Trusted Partner',
    description: 'HVAC, plumbing, electrical, handyman, and renovation services under one roof.',
    metric: 'Single Source',
    highlight: 'Consolidated vendor billing',
  },
];

export const CORE_SERVICES: ServiceDetail[] = [
  {
    id: 'hvac',
    title: 'HVAC Services',
    tagline: 'Climate Control & System Reliability',
    description:
      'Reliable heating, ventilation, and air conditioning systems are essential for employee comfort and business operations.',
    iconName: 'Wind',
    popularFor: 'Rooftop Units, Chillers, Split Systems & Air Quality',
    includedServices: [
      'HVAC Maintenance',
      'System Inspections',
      'Troubleshooting & Repairs',
      'Filter Replacement',
      'Thermostat Installation & Upgrades',
      'Commercial Unit Servicing',
      'Preventive Maintenance Programs',
    ],
  },
  {
    id: 'plumbing',
    title: 'Commercial Plumbing',
    tagline: 'Water Systems & Fixture Efficiency',
    description:
      'Our plumbing solutions help keep your facility operating efficiently while minimizing disruptions.',
    iconName: 'Droplets',
    popularFor: 'Restroom Banks, Backflow Prevention & Supply Lines',
    includedServices: [
      'Leak Detection & Repairs',
      'Fixture Installation & Replacement',
      'Pipe Repairs',
      'Water Line Maintenance',
      'Restroom Plumbing Services',
      'Commercial Plumbing Maintenance',
      'Drain Cleaning (Non-Excavation)',
    ],
  },
  {
    id: 'electrical',
    title: 'Electrical Services',
    tagline: 'Power, Lighting & System Safety',
    description:
      'We provide dependable electrical services for commercial facilities, helping ensure safety and operational reliability.',
    iconName: 'Zap',
    popularFor: 'Distribution Panels, Commercial Lighting & Code Compliance',
    includedServices: [
      'Electrical Repairs',
      'Lighting Installation & Upgrades',
      'LED Retrofits',
      'Outlet & Switch Replacement',
      'Electrical Troubleshooting',
      'Preventive Maintenance',
      'Facility Electrical Improvements',
    ],
  },
  {
    id: 'handyman',
    title: 'Handyman Services',
    tagline: 'Routine Maintenance & Facility Upkeep',
    description:
      'Routine repairs and maintenance play a critical role in keeping commercial properties professional and functional.',
    iconName: 'Wrench',
    popularFor: 'Acoustic Ceilings, Hardware, Drywall & Preventive Upkeep',
    includedServices: [
      'General Repairs',
      'Ceiling Tile Replacement',
      'Door & Hardware Repairs',
      'Drywall Repairs',
      'Painting & Touch-Ups',
      'Fixture Installation',
      'Preventive Maintenance Tasks',
    ],
  },
  {
    id: 'renovation',
    title: 'Commercial Renovations',
    tagline: 'Interior Improvements & Tenant Buildouts',
    description:
      'Improve your facility’s appearance and functionality with professional renovation solutions.',
    note: 'Note: We perform renovations and interior improvements only. We do not provide excavation services.',
    iconName: 'Building2',
    popularFor: 'Tenant Turnovers, Modernization & Layout Reconfiguration',
    includedServices: [
      'Office Renovations',
      'Tenant Improvements',
      'Interior Remodeling',
      'Flooring Installation',
      'Painting & Finishing',
      'Partition & Drywall Installation',
      'Facility Upgrades & Modernization',
    ],
  },
];

export const INDUSTRIES_SERVED = [
  {
    name: 'Office Buildings',
    desc: 'Executive suites, corporate parks, and co-working facilities requiring quiet, clean maintenance.',
    icon: 'Briefcase',
  },
  {
    name: 'Retail Centers',
    desc: 'High-foot-traffic storefronts and shopping plazas with strict lighting and comfort standards.',
    icon: 'ShoppingBag',
  },
  {
    name: 'Warehouses',
    desc: 'Logistics hubs, high-bay storage, and distribution facilities needing robust electrical and HVAC.',
    icon: 'Boxes',
  },
  {
    name: 'Industrial Facilities',
    desc: 'Manufacturing plants, workshops, and light industrial units requiring durable repairs.',
    icon: 'Factory',
  },
  {
    name: 'Healthcare Facilities',
    desc: 'Clinics, dental centers, and medical offices requiring hygienic, compliant maintenance.',
    icon: 'Activity',
  },
  {
    name: 'Restaurants',
    desc: 'Dining rooms, commercial kitchens, and franchise locations needing rapid plumbing & HVAC.',
    icon: 'UtensilsCrossed',
  },
  {
    name: 'Educational Facilities',
    desc: 'Private academies, trade centers, and daycare facilities prioritizing safety and reliability.',
    icon: 'GraduationCap',
  },
  {
    name: 'Commercial Properties & Property Management Companies',
    desc: 'Portfolio managers looking for a single accountable contractor to handle multiple commercial leases.',
    icon: 'Building',
  },
];

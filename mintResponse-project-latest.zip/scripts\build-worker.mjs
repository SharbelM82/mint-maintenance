import { copyFile, writeFile, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const root = new URL('../', import.meta.url);
await access(new URL('dist/index.html', root));
await copyFile(new URL('worker/service-request.mjs', root), new URL('dist/_worker.js', root));
await writeFile(new URL('dist/_routes.json', root), JSON.stringify({
  version: 1,
  include: ['/api/*'],
  exclude: [],
}, null, 2) + '\n');
console.log('Cloudflare Pages worker added to ' + fileURLToPath(new URL('dist/', root)));

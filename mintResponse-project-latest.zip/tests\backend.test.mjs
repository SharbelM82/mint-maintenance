import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { handleRequest, validateSubmission } from '../worker/service-request.mjs';
const URL = 'https://mintresponse.com/api/service-request';
const endpoint = 'https://formspree.io/f/testform'; // Used only with an injected mock, never fetched.
const fields = {
  fullName: 'QA Test', businessName: 'QA Company', phone: '+1 (555) 010-2000',
  email: 'qa@example.com', propertyType: 'Office Buildings', locationCity: 'Centerton, AR',
  primaryService: 'hvac', urgency: 'urgent', projectScope: 'Test only. No actual service required.',
};
function request(body = fields, options = {}) {
  return new Request(URL, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'https://mintresponse.com' },
    body: JSON.stringify(body), ...options,
  });
}
const noNetwork = { fetch: async () => { throw new Error('Unexpected network request'); } };
test('validates and trims submitted fields', () => {
  assert.equal(validateSubmission({ ...fields, fullName: ' QA Test ' }).fullName, 'QA Test');
});
test('rejects missing fields, bad enums, arrays, CRLF and invalid email/phone', () => {
  for (const bad of [null, [], {}, { ...fields, fullName: '  ' }, { ...fields, email: 'bad' },
    { ...fields, email: 'qa@example.com\r\nBcc:other@example.com' }, { ...fields, phone: 'abc123' },
    { ...fields, primaryService: 'unsupported' }, { ...fields, urgency: 'now' },
    { ...fields, propertyType: 'Office Building' }, { ...fields, projectScope: 'x'.repeat(5001) }]) {
    assert.equal(validateSubmission(bad), null);
  }
});
test('rejects wrong routes and methods', async () => {
  assert.equal((await handleRequest(new Request('https://mintresponse.com/api/other'))).status, 404);
  const response = await handleRequest(new Request(URL));
  assert.equal(response.status, 405); assert.equal(response.headers.get('allow'), 'POST');
});
test('rejects cross-origin or missing-origin browser requests', async () => {
  for (const origin of ['https://other.example', '', 'null']) {
    const response = await handleRequest(request(fields, { headers: { Origin: origin, 'Content-Type': 'application/json' } }), {}, noNetwork);
    assert.equal(response.status, 403);
  }
});
test('rejects incorrect content type and invalid JSON', async () => {
  assert.equal((await handleRequest(request(fields, { headers: { Origin: 'https://mintresponse.com', 'Content-Type': 'text/plain' } }))).status, 415);
  assert.equal((await handleRequest(request(fields, { body: '{broken' }))).status, 400);
});
test('enforces body limit even without Content-Length', async () => {
  assert.equal((await handleRequest(request(fields, { body: 'x'.repeat(17000) }))).status, 413);
});
test('enforces Content-Length limit', async () => {
  const response = await handleRequest(request(fields, { headers: { Origin: 'https://mintresponse.com', 'Content-Type': 'application/json', 'Content-Length': '999999' } }));
  assert.equal(response.status, 413);
});
test('rejects filled honeypot without issuing a fake receipt', async () => {
  const response = await handleRequest(request({ ...fields, companyWebsite: 'spam' }), {}, noNetwork);
  assert.equal(response.status, 400); assert.equal((await response.json()).ok, false);
});
test('requires a configured, approved Formspree destination', async () => {
  for (const bad of [undefined, '', 'http://formspree.io/f/test', 'https://evil.example/f/test', 'https://formspree.io@evil.example/f/test', endpoint + '?redirect=evil']) {
    const response = await handleRequest(request(), { CONTACT_FORM_ENDPOINT: bad }, noNetwork);
    assert.equal(response.status, 503);
  }
});
test('returns receipt only after explicit provider confirmation', async () => {
  let payload;
  const response = await handleRequest(request(), { CONTACT_FORM_ENDPOINT: endpoint }, {
    fetch: async (url, options) => {
      assert.equal(url, endpoint); assert.equal(options.redirect, 'error');
      payload = JSON.parse(options.body);
      return Response.json({ ok: true });
    },
    randomUUID: () => '00000000-0000-4000-8000-000000000001',
    now: () => '2026-09-06T20:00:00.000Z',
  });
  const result = await response.json();
  assert.equal(response.status, 201); assert.equal(result.ok, true);
  assert.equal(result.id, payload.reference); assert.equal(payload.email, fields.email);
  assert.equal(payload.projectScope, fields.projectScope);
  assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.ok(!('fullName' in result));
});
test('does not turn an ambiguous 2xx, CAPTCHA or error into success', async () => {
  for (const body of [{}, { next: 'captcha' }, { ok: false }, { ok: true, errors: ['captcha'] }]) {
    const response = await handleRequest(request(), { CONTACT_FORM_ENDPOINT: endpoint }, { fetch: async () => Response.json(body) });
    assert.equal(response.status, 502); assert.equal((await response.json()).ok, false);
  }
});
test('does not accept HTML masquerading as successful delivery', async () => {
  const response = await handleRequest(request(), { CONTACT_FORM_ENDPOINT: endpoint }, { fetch: async () => new Response('<html>challenge</html>', { headers: { 'Content-Type': 'text/html' } }) });
  assert.equal(response.status, 502);
});
test('preserves rate-limit failure status', async () => {
  const response = await handleRequest(request(), { CONTACT_FORM_ENDPOINT: endpoint }, { fetch: async () => Response.json({ errors: ['limit'] }, { status: 429 }) });
  assert.equal(response.status, 429);
});
test('handles provider rejection, broken JSON and network failures', async () => {
  for (const fetch of [
    async () => Response.json({ ok: false }, { status: 500 }),
    async () => new Response('{broken', { headers: { 'Content-Type': 'application/json' } }),
    async () => { throw new Error('offline'); },
  ]) {
    const response = await handleRequest(request(), { CONTACT_FORM_ENDPOINT: endpoint }, { fetch });
    assert.equal(response.status, 502);
  }
});
test('aborts a stalled provider request without a success receipt', async () => {
  const response = await handleRequest(request(), { CONTACT_FORM_ENDPOINT: endpoint }, {
    timeoutMs: 5,
    fetch: (_, options) => new Promise((_, reject) => options.signal.addEventListener('abort', () => reject(new Error('timeout')))),
  });
  assert.equal(response.status, 502);
});
test('serves non-API assets using the Cloudflare ASSETS binding', async () => {
  const response = await worker.fetch(new Request('https://mintresponse.com/'), { ASSETS: { fetch: async () => new Response('asset') } });
  assert.equal(await response.text(), 'asset');
});

import React from 'react';
import { Target, Compass, MapPin } from 'lucide-react';
import { COMPANY_INFO } from '../data/facilityData';
import { MintLogo } from './MintLogo';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* About Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300/60 text-xs font-bold uppercase tracking-wider">
            About Our Company
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            About Mint Response
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            A dedicated commercial maintenance and facility partner, built on accountability and swift communication.
          </p>
        </div>

        {/* Grid: Story & Goal Statement */}
        <div className="grid lg:grid-cols-12 gap-10 items-stretch mb-16">
          
          {/* Main Story & Purpose */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-8 sm:p-10 shadow-xs flex flex-col justify-between space-y-6">
            {/* Official Brand Identity Card */}
            <div className="flex flex-col sm:flex-row items-center gap-7 p-7 rounded-2xl bg-slate-50 border border-slate-200 shadow-xs">
              <div className="shrink-0 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <MintLogo variant="full" size="md" />
              </div>
              <div className="space-y-3 text-center sm:text-left">
                <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 bg-slate-200/70 border border-slate-300 px-3 py-1 rounded-md">
                  Official Entity & Trademark
                </span>
                <h4 className="font-display font-extrabold text-2xl text-slate-900">
                  Mint Response
                </h4>
                <p className="text-slate-600 text-sm leading-relaxed">
                  Registered commercial facility management entity operating through Arkansas, Texas, Florida. Committed to pristine craftsmanship, swift technical dispatch, and guaranteed accountability.
                </p>
                <div className="pt-2 text-xs font-semibold text-emerald-800 flex items-center justify-center sm:justify-start gap-1.5">
                  <span>Authorized Commercial Contractor</span>
                </div>
              </div>
            </div>

            <div className="space-y-5 text-slate-700 text-base sm:text-lg leading-relaxed">
              <p>
                {COMPANY_INFO.aboutDescription1}
              </p>
              <p>
                {COMPANY_INFO.aboutDescription2}
              </p>
            </div>

            {/* Simple Goal Box */}
            <div className="p-6 rounded-xl bg-slate-900 text-white border border-slate-800 shadow-lg">
              <p className="text-xs uppercase tracking-wider font-bold text-emerald-300 mb-1">
                Our Foundational Promise
              </p>
              <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                "{COMPANY_INFO.goalStatement}"
              </h3>
            </div>

            <p className="text-slate-600 text-sm italic">
              {COMPANY_INFO.aboutClosing}
            </p>
          </div>

          {/* Mission & Vision Cards */}
          <div className="lg:col-span-5 space-y-6 flex flex-col">
            
            {/* Our Mission */}
            <div className="flex-1 bg-white rounded-2xl border border-slate-200 p-8 shadow-xs hover:border-emerald-500/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-emerald-100/70 text-emerald-600 flex items-center justify-center mb-5 shadow-xs">
                <Target className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                Core Purpose
              </span>
              <h3 className="font-display text-2xl font-bold text-slate-900 mt-1 mb-3">
                Our Mission
              </h3>
              <p className="text-slate-600 text-base leading-relaxed">
                {COMPANY_INFO.mission}
              </p>
            </div>

            {/* Our Vision */}
            <div className="flex-1 bg-white rounded-2xl border border-slate-200 p-8 shadow-xs hover:border-emerald-500/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center mb-5">
                <Compass className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                Forward Horizon
              </span>
              <h3 className="font-display text-2xl font-bold text-slate-900 mt-1 mb-3">
                Our Vision
              </h3>
              <p className="text-slate-600 text-base leading-relaxed">
                {COMPANY_INFO.vision}
              </p>
            </div>

          </div>

        </div>


      </div>
    </section>
  );
};

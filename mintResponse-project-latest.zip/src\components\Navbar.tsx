import React, { useState } from 'react';
import { Mail, Clock, Menu, X, Wrench } from 'lucide-react';
import { COMPANY_INFO } from '../data/facilityData';
import { MintLogo } from './MintLogo';

interface NavbarProps {
  onRequestService: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onRequestService }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Home', href: '/#home' },
    { name: 'Services', href: '/#services' },
    { name: 'Industries', href: '/#industries' },
    { name: 'Why Us', href: '/#why-us' },
    { name: 'About Us', href: '/#about' },
    { name: 'Gallery', href: '/gallery' },
    { name: 'Contact', href: '/#contact' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top Commercial Emergency / Information Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="inline-flex items-center gap-1.5 font-medium text-emerald-400">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Commercial Facility Solutions
            </span>
            <span className="hidden md:inline text-slate-600">|</span>
            <span className="hidden md:flex items-center gap-1 text-slate-400">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              {COMPANY_INFO.businessHours}
            </span>
            <span className="hidden lg:inline text-amber-300 font-medium">
              • {COMPANY_INFO.emergencyNotice}
            </span>
          </div>

          <div className="flex items-center gap-5">
            <a
              href={`mailto:${COMPANY_INFO.email}`}
              className="hidden sm:inline-flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
            >
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              {COMPANY_INFO.email}
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 sm:h-24">
          {/* Brand Logo - Official Emblem with Written Company Name */}
          <a href="/#home" className="flex items-center group py-1.5 focus:outline-none" aria-label="Mint Response Home">
            <MintLogo variant="horizontal" theme="light" size="lg" />
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-3 lg:gap-7 xl:gap-8 min-w-0">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-xs lg:text-sm font-bold text-slate-700 hover:text-emerald-600 transition-colors py-1 relative whitespace-nowrap hover:after:w-full after:transition-all after:duration-200 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-emerald-500"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Action Button */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <button
              onClick={onRequestService}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-emerald-500 text-white text-sm font-bold shadow-lg shadow-emerald-500/25 hover:bg-emerald-400 active:scale-[0.98] transition-all cursor-pointer"
            >
              <Wrench className="w-4 h-4" />
              <span>Request a Service</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={onRequestService}
              className="px-3 py-2 text-xs font-bold rounded bg-emerald-500 text-white shadow-xs"
            >
              Request
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 shadow-lg animate-in slide-in-from-top-2 duration-200">
          <div className="space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-md text-base font-medium text-slate-800 hover:bg-slate-100 hover:text-emerald-600"
              >
                {link.name}
              </a>
            ))}
          </div>

        </div>
      )}
    </header>
  );
};

import React, { useState } from 'react';
import { 
  Briefcase, 
  ShoppingBag, 
  Boxes, 
  Factory, 
  Activity, 
  UtensilsCrossed, 
  GraduationCap, 
  Building,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import { INDUSTRIES_SERVED } from '../data/facilityData';

interface IndustriesSectionProps {
  onRequestService: (propertyType: string) => void;
}

export const IndustriesSection: React.FC<IndustriesSectionProps> = ({ onRequestService }) => {
  const [selectedIndustry, setSelectedIndustry] = useState(0);

  const getIndustryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Briefcase':
        return <Briefcase className="w-5 h-5" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-5 h-5" />;
      case 'Boxes':
        return <Boxes className="w-5 h-5" />;
      case 'Factory':
        return <Factory className="w-5 h-5" />;
      case 'Activity':
        return <Activity className="w-5 h-5" />;
      case 'UtensilsCrossed':
        return <UtensilsCrossed className="w-5 h-5" />;
      case 'GraduationCap':
        return <GraduationCap className="w-5 h-5" />;
      case 'Building':
        return <Building className="w-5 h-5" />;
      default:
        return <Building className="w-5 h-5" />;
    }
  };

  return (
    <section id="industries" className="py-24 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300/60 text-xs font-bold uppercase tracking-wider">
            Commercial Sectors
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Industries We Serve
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Mint Response provides customized solutions for high-demand business environments.
          </p>
        </div>

        {/* 8 Industries Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {INDUSTRIES_SERVED.map((industry, index) => {
            const isSelected = selectedIndustry === index;
            return (
              <div
                key={industry.name}
                onClick={() => setSelectedIndustry(index)}
                className={`p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xl scale-[1.02]'
                    : 'bg-slate-50/70 border-slate-200 text-slate-800 hover:bg-white hover:border-emerald-500/40 hover:shadow-sm'
                }`}
              >
                <div>
                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center mb-5 transition-all ${
                      isSelected
                        ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30'
                        : 'bg-white border border-slate-200 text-emerald-500 shadow-2xs'
                    }`}
                  >
                    {getIndustryIcon(industry.icon)}
                  </div>

                  <h3
                    className={`font-display text-lg font-bold mb-2 ${
                      isSelected ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {industry.name}
                  </h3>

                  <p
                    className={`text-xs leading-relaxed ${
                      isSelected ? 'text-slate-300' : 'text-slate-600'
                    }`}
                  >
                    {industry.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-200/50 flex items-center justify-between">
                  <span
                    className={`text-[11px] font-bold ${
                      isSelected ? 'text-emerald-300' : 'text-emerald-600'
                    }`}
                  >
                    Custom Solutions
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRequestService(industry.name);
                    }}
                    className={`text-xs font-bold inline-flex items-center gap-1 py-1 px-2.5 rounded-md transition-colors ${
                      isSelected
                        ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow-xs'
                        : 'bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200'
                    }`}
                  >
                    <span>Request</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>


      </div>
    </section>
  );
};

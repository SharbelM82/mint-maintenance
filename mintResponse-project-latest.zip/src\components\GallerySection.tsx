import React from 'react';
import { Image, MapPin } from 'lucide-react';

const PROJECT_PLACEHOLDERS = [
  {
    title: 'Commercial Facility Project',
    category: 'HVAC & Maintenance',
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Commercial Facility Project',
    category: 'Plumbing Services',
    imageUrl: 'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Commercial Facility Project',
    category: 'Electrical Services',
    imageUrl: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Commercial Facility Project',
    category: 'Handyman Services',
    imageUrl: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Commercial Facility Project',
    category: 'Interior Improvements',
    imageUrl: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Commercial Facility Project',
    category: 'Preventive Maintenance',
    imageUrl: 'https://images.unsplash.com/photo-1581244277943-fe4a9c777189?auto=format&fit=crop&w=900&q=80',
  },
];

export const GallerySection: React.FC = () => {
  return (
    <section id="gallery" className="py-24 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300/60 text-xs font-bold tracking-wide uppercase">
            <Image className="w-4 h-4 text-emerald-600" />
            Project Gallery
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Our Completed Projects
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Preview how completed commercial maintenance and improvement projects can be showcased.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROJECT_PLACEHOLDERS.map((project, index) => (
            <article
              key={`${project.category}-${index}`}
              className="overflow-hidden rounded-2xl bg-white border border-slate-200 shadow-sm"
            >
              <div className="aspect-[4/3] bg-slate-200 overflow-hidden">
                <img
                  src={project.imageUrl}
                  alt={`${project.category} preview`}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
              <div className="p-5 space-y-2">
                <p className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                  {project.category}
                </p>
                <h3 className="font-display text-xl font-bold text-slate-900">{project.title}</h3>
                <p className="inline-flex items-center gap-1.5 text-sm text-slate-500">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  Commercial project
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

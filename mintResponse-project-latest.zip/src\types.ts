export type ServiceCategory = 
  | 'hvac'
  | 'plumbing'
  | 'electrical'
  | 'handyman'
  | 'renovation'
  | 'comprehensive';

export type UrgencyLevel = 'emergency' | 'urgent' | 'scheduled';

export type CommercialPropertyType = 
  | 'Office Building'
  | 'Retail Center'
  | 'Warehouse'
  | 'Industrial Facility'
  | 'Healthcare Facility'
  | 'Restaurant'
  | 'Educational Facility'
  | 'Commercial Property Management';

export interface ServiceDetail {
  id: ServiceCategory;
  title: string;
  tagline: string;
  description: string;
  includedServices: string[];
  note?: string;
  iconName: string;
  popularFor: string;
}

export interface ServiceRequestSubmission {
  id: string;
  fullName: string;
  businessName: string;
  phone: string;
  email: string;
  propertyType: string;
  locationCity: string;
  primaryService: ServiceCategory;
  urgency: UrgencyLevel;
  projectScope: string;
  submittedAt: string;
  status: 'Received' | 'Assigned' | 'In Review';
}

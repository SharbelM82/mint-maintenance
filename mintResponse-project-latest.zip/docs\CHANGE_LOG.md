# Applied changes — original source only

Prepared September 6, 2026 from `remix-mint-response-llc.zip` and the six-page `2026-09-06 Requested Website Changes.docx`.

The source, logo, original fonts, colors, CSS, single-page organization and surviving layout classes are retained. No prior modified-site files were used as the base.

## Changes requested in the document

| Document | Original item | Applied result |
|---|---|---|
| Page 1 | Kansas in the displayed header | `Kansas Commercial Facility Solutions` becomes `Commercial Facility Solutions`. |
| Page 1 | Kansas in the shared logo subtitle | Remove ` • Kansas`; the same logo component also changes in the footer. The SVG artwork is untouched. |
| Page 1 | Kansas in the hero badge | Remove `Kansas, USA • ` only. |
| Page 1 | Hero description | Remove ` across Kansas` from the specified sentence. The shared description also changes in the footer. |
| Pages 1 and 5 | Operating hours | `Monday – Sunday 8 am to 5 pm CT`. The shared setting updates the header, contact card and footer. |
| Page 1 | `Commercial Facility Matrix` | `Commercial Facility`. |
| Page 1 | Three-metric strip | Remove the complete 100% / 5-in-1 / Kansas statewide coverage strip. |
| Page 2 | Welcome card headquarters line | Remove `Headquartered in Kansas`; retain `Fast Response`. |
| Page 2 | Floating regional box | Remove the complete KS / Regional Commercial Care box. |
| Page 2 | Why Us introduction | Remove the exact words `facing Kansas`, as instructed. No grammar rewrite. |
| Page 3 | Detailed Commercial Renovations card | Remove only this card from the Core Services grid. The associated filter is also removed to avoid an empty tab, and the all-services count now shows 4. The grid classes remain unchanged. |
| Page 3 | Entity-card operating description | Replace `operating statewide throughout Kansas` with `operating through Arkansas, Texas, Florida`. Rest of the sentence unchanged. |
| Page 4 | About description | Replace `Mint Response LLC is a Kansas-based facility management` with `Mint Response LLC is an Arkansas-based facility management`. Rest of the paragraph unchanged. |
| Page 4 | Service-regions box | Remove the complete regional coverage box, not the About section. |
| Page 5 | Portfolio banner | Remove the complete `Manage Multiple Commercial Properties in Kansas?` banner. |
| Page 5 | Headquarters location | `Centerton, AR`. The shared location also updates the footer location value. |
| Page 5 | Contact detail annotations | Remove the state-coverage line, `Direct Commercial Line`, and `Bid requests & work orders`. |
| Page 6 | Final sentence after Note | Remove only `We do not provide excavation services.` from the footer. Retain `Note: We perform commercial renovations and interior improvements only.` |

## Scope interpretations — made explicit

The instruction document identifies specific screenshots and text. Its Kansas removals were applied to the identified areas, not expanded into a global rewrite. Unmarked geographic references remain; see UNCHANGED_ITEMS.md.

Removing `facing Kansas` literally leaves `...pain points commercial property managers.` This has not been silently rewritten. Removing only the final sentence after `Note:` leaves the preceding sentence. These two interpretations are visible in the preview and should be confirmed before publication.

The document removes the detailed renovations box, not every mention of renovations on the site. Those other mentions remain. The removal of its filter and correction of the card count are limited functional consequences of removing that box, not a redesign.

## Backend and build changes

The original form waited 600 ms, generated a random browser-only ticket and put personal information in localStorage. Nothing was transmitted. The replacement posts to `/api/service-request`, validates on the server and forwards to an owner-configured Formspree form. Success requires an explicit successful JSON response; an unconfigured endpoint, error, redirect, CAPTCHA/ambiguous response or timeout does not produce a receipt. Inputs are kept on failure; failure information uses a native alert rather than changing the page layout.

The default property-type value now matches the first existing dropdown option (`Office Buildings`) rather than the nonexistent singular value (`Office Building`). This corrects the submitted data without changing the displayed option. A hidden honeypot was added with no visible form row. Ticket IDs are server-generated, collision-resistant MR references rather than browser random four-digit MR-KS references.

Added server validation, body-size limits, origin checks, delivery timeout, backend tests, original-content guards, a Cloudflare Pages worker, Vite development/preview API middleware, server configuration examples, GitHub CI and Cursor instructions. Origin checks and a honeypot are not a comprehensive anti-bot service.

Unused AI/Express/dotenv/motion packages were removed; the exported website does not use them. The original React, Lucide, Tailwind and Vite dependency ranges were retained. React type declarations were added for type checking. Development binds to localhost, not the public network. No Gemini key is needed. No package lockfile was invented.

No accounts, DNS records, inboxes or live deployments were changed. No customer data or test inquiries were sent to a provider.

## Owner-directed follow-up (September 9, 2026)

| Instruction | Applied result |
|---|---|
| Refer to the company exclusively as Mint Response, not Mint Response LLC | Public copy, page title, form ticket text, and rendered wordmarks use `Mint Response`. The LLC badge was removed from the header, footer, contact, and About logo lockups. Official SVG asset files were not rewritten. |
| Remove the header phone placeholder | The top bar and mobile-menu `tel:` links for `(xxx) xxx-xxxx` were removed. |
| Remove remaining Kansas references | Visible Kansas copy, Kansas city examples, unused Kansas hub data, and Kansas SEO title/description wording were removed. Geographic phrases were dropped or replaced with non-state wording already used elsewhere (`the region`, `commercial properties`). No new state-licensing claim was added. |
| Use 479-341-5787 for contact and footer | Shared `phonePlaceholder` / `phoneDisplay` now show `479-341-5787` on the contact card and footer. The header remains without a phone. |
| Remove the footer Note line | The bottom-of-page sentence `Note: We perform commercial renovations and interior improvements only.` was removed. The copyright line remains. The contact form excavation/renovations note was not changed. |
| Show top navigation in the working preview | Desktop nav links now appear from the `md` breakpoint. The hamburger is limited to narrower viewports so it matches the dropdown. |
| Reorder top nav | Header order is `Home`, `Services`, `Industries`, `Why Us`, `About Us`, `Contact`. |

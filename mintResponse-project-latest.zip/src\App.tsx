import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { WelcomeSection } from './components/WelcomeSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ServicesSection } from './components/ServicesSection';
import { CommercialMaintenancePlanner } from './components/CommercialMaintenancePlanner';
import { AboutSection } from './components/AboutSection';
import { IndustriesSection } from './components/IndustriesSection';
import { GallerySection } from './components/GallerySection';
import { ContactAndRequestSection } from './components/ContactAndRequestSection';
import { Footer } from './components/Footer';
import { ServiceCategory } from './types';

export default function App() {
  const [selectedService, setSelectedService] = useState<ServiceCategory | null>(null);
  const [selectedPropertyType, setSelectedPropertyType] = useState<string | null>(null);
  const isGalleryPage = window.location.pathname === '/gallery';

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleRequestService = (serviceId?: ServiceCategory) => {
    if (serviceId) {
      setSelectedService(serviceId);
    }
    scrollToSection('contact');
  };

  const handleIndustrySelect = (propertyType: string) => {
    setSelectedPropertyType(propertyType);
    scrollToSection('contact');
  };

  const handlePlanSelected = (summary: string) => {
    setSelectedService('comprehensive');
    scrollToSection('contact');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Navigation */}
      <Navbar onRequestService={() => handleRequestService()} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {isGalleryPage ? (
          <GallerySection />
        ) : (
          <>
        {/* Hero Section */}
        <Hero 
          onRequestService={() => handleRequestService()} 
          onContactClick={() => scrollToSection('contact')} 
        />

        {/* Welcome Section */}
        <WelcomeSection 
          onLearnMoreServices={() => scrollToSection('services')} 
        />

        {/* Core Services Section with Detail Breakdown */}
        <ServicesSection 
          onSelectServiceForRequest={(id) => handleRequestService(id)} 
        />

        {/* Interactive Commercial Maintenance Cadence / Preventive Programs */}
        <CommercialMaintenancePlanner 
          onPlanSelected={handlePlanSelected} 
        />

        {/* Industries We Serve */}
        <IndustriesSection 
          onRequestService={handleIndustrySelect} 
        />

        {/* Why Choose Mint Response? */}
        <WhyChooseUs 
          onRequestService={() => handleRequestService()} 
        />

        {/* About Mint Response, Mission and Vision */}
        <AboutSection />

        {/* Contact Us & Request a Service Interactive Form */}
        <ContactAndRequestSection 
          preselectedService={selectedService}
          preselectedPropertyType={selectedPropertyType}
        />
          </>
        )}
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}

const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
let count=0, failed=false;
function visit(dir) {
 for(const item of fs.readdirSync(dir,{withFileTypes:true})) {
  if(['node_modules','dist','.git','reference','review'].includes(item.name))continue;
  const file=path.join(dir,item.name);
  if(item.isDirectory())visit(file);
  else if(/\.tsx?$/.test(item.name)) {
   const out=ts.transpileModule(fs.readFileSync(file,'utf8'),{
    fileName:file, reportDiagnostics:true,
    compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX,isolatedModules:true},
   });
   for(const d of out.diagnostics||[])if(d.category===ts.DiagnosticCategory.Error){failed=true;console.error(file,ts.flattenDiagnosticMessageText(d.messageText,' '));}
   count++;
  }
 }
}
visit(root); if(failed)process.exit(1);
console.log(`${count} TypeScript/TSX files transpile without syntax diagnostics. This is NOT a dependency-resolved type check or Vite build.`);

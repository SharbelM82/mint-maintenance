import React, { useState } from 'react';
import { Calendar, CheckSquare, Shield, Sliders, ArrowRight, Sparkles, Building, Layers } from 'lucide-react';
import { ServiceCategory } from '../types';

interface CommercialMaintenancePlannerProps {
  onPlanSelected: (summary: string) => void;
}

export const CommercialMaintenancePlanner: React.FC<CommercialMaintenancePlannerProps> = ({ onPlanSelected }) => {
  const [propertySize, setPropertySize] = useState<string>('25k');
  const [selectedTrades, setSelectedTrades] = useState<Record<string, boolean>>({
    hvac: true,
    plumbing: true,
    electrical: true,
    handyman: true,
  });

  const toggleTrade = (key: string) => {
    setSelectedTrades(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const tradeDetails: Record<string, { label: string; cadence: string; tasks: string[] }> = {
    hvac: {
      label: 'HVAC Care',
      cadence: 'Quarterly',
      tasks: ['Filter replacement', 'Thermostat calibration', 'Belt & compressor inspection', 'Seasonal tune-up'],
    },
    plumbing: {
      label: 'Commercial Plumbing',
      cadence: 'Bi-Annual',
      tasks: ['Restroom fixture seals', 'Backflow & leak detection', 'Water heater check', 'Drain clearing'],
    },
    electrical: {
      label: 'Electrical Safety',
      cadence: 'Semi-Annual',
      tasks: ['Panel inspection & thermal check', 'Emergency lighting test', 'LED fixture retrofits', 'Outlet testing'],
    },
    handyman: {
      label: 'Facility Upkeep',
      cadence: 'Monthly / On-Demand',
      tasks: ['Ceiling tile replacements', 'Door hardware adjustment', 'Drywall repairs & touch-up paint', 'General hardware'],
    },
  };

  const handleApplyToRequest = () => {
    const active = Object.keys(selectedTrades).filter(k => selectedTrades[k]).map(k => tradeDetails[k].label);
    const summary = `Preventive Maintenance Program (~${propertySize} sq ft facility) including: ${active.join(', ')}`;
    onPlanSelected(summary);
  };

  return (
    <section className="py-20 bg-slate-900 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Info */}
          <div className="lg:col-span-5 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>Preventive Facility Strategy</span>
            </div>

            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Preventive Maintenance Programs
            </h2>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Eliminate emergency repair premiums and unexpected tenant disruptions. Mint Response customizes scheduled maintenance programs covering routine inspections, filter cycles, and safety checks under a single master service contract.
            </p>

            <div className="p-4 rounded-xl bg-slate-800/80 border border-emerald-500/30 space-y-2 shadow-xs">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                <Shield className="w-4 h-4 text-emerald-300" />
                <span>Protect Commercial Asset Value</span>
              </div>
              <p className="text-xs text-slate-300">
                Regular preventive servicing extends HVAC system lifespan by up to 35% and maintains professional tenant presentation across commercial properties.
              </p>
            </div>
          </div>

          {/* Right Interactive Plan Builder */}
          <div className="lg:col-span-7 bg-slate-800/90 border border-slate-700 rounded-2xl p-6 sm:p-8">
            <div className="flex items-center justify-between pb-5 border-b border-slate-700">
              <div>
                <h3 className="text-lg font-bold text-white">
                  Customize Your Facility Cadence
                </h3>
                <p className="text-xs text-slate-400">
                  Select your facility scale and required trade disciplines
                </p>
              </div>
              <span className="text-xs font-bold bg-emerald-500/25 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-500/40">
                Commercial
              </span>
            </div>

            {/* Facility Size Selector */}
            <div className="pt-5 pb-4">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Estimated Commercial Floor Area
              </label>
              <div className="grid grid-cols-4 gap-2.5">
                {[
                  { id: '10k', label: '< 10,000 sq ft' },
                  { id: '25k', label: '10k – 25k sq ft' },
                  { id: '50k', label: '25k – 75k sq ft' },
                  { id: '100k', label: '75k+ sq ft' },
                ].map((size) => (
                  <button
                    key={size.id}
                    onClick={() => setPropertySize(size.id)}
                    className={`py-2 px-1 text-center text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                      propertySize === size.id
                        ? 'bg-emerald-500 text-white border-emerald-400 shadow-md shadow-emerald-500/25'
                        : 'bg-slate-900/80 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    {size.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Trade Checkbox Cards */}
            <div className="py-4 space-y-3">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                Included Trade Programs
              </label>
              <div className="grid sm:grid-cols-2 gap-3">
                {Object.entries(tradeDetails).map(([key, data]) => {
                  const isChecked = selectedTrades[key];
                  return (
                    <div
                      key={key}
                      onClick={() => toggleTrade(key)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-slate-900/90 border-emerald-400 shadow-sm shadow-emerald-500/10'
                          : 'bg-slate-900/40 border-slate-700/60 opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white flex items-center gap-2">
                          <span className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                            isChecked ? 'bg-emerald-400 text-slate-950 font-black shadow-xs' : 'border border-slate-600'
                          }`}>
                            {isChecked ? '✓' : ''}
                          </span>
                          {data.label}
                        </span>
                        <span className="text-[10px] font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded">
                          {data.cadence}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-2 line-clamp-1">
                        {data.tasks.join(' • ')}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Apply Button */}
            <div className="pt-4 border-t border-slate-700/80 flex items-center justify-between gap-4">
              <span className="text-xs text-slate-400">
                Builds into a customized work proposal
              </span>
              <button
                onClick={handleApplyToRequest}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 transition-all cursor-pointer"
              >
                <span>Request Custom Program Quote</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};

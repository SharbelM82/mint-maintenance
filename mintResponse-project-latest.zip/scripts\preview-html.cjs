/* Review-only HTML from the actual TSX source. Not the production build. */
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');

function createPreview(sourceRoot, outputPath, label) {
  const files = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(p);
      else if (/\.tsx?$/.test(entry.name)) files.push(p);
    }
  }
  walk(path.join(sourceRoot, 'src'));
  const definitions = files.map(file => {
    const id = path.relative(sourceRoot, file).replaceAll(path.sep, '/').replace(/\.tsx?$/, '');
    const result = ts.transpileModule(fs.readFileSync(file, 'utf8'), {
      compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
        jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true, isolatedModules: true },
      fileName: file, reportDiagnostics: true,
    });
    if (result.diagnostics?.some(d => d.category === ts.DiagnosticCategory.Error)) throw new Error('TSX syntax error: ' + file);
    return JSON.stringify(id) + ': function(require,module,exports){\n' + result.outputText + '\n}';
  }).join(',\n');
  const css = fs.readFileSync(path.join(sourceRoot, 'src/index.css'), 'utf8');
  const originalHTML = fs.readFileSync(path.join(sourceRoot, 'index.html'), 'utf8');
  const fontLinks = [...originalHTML.matchAll(/<link[^>]+(?:fonts\.googleapis\.com|fonts\.gstatic\.com)[^>]*>/g)].map(m => m[0]).join('\n');
  const favicon = 'data:image/svg+xml;base64,' + fs.readFileSync(path.join(sourceRoot, 'public/mint-logo-icon.svg')).toString('base64');
  const html = `<!doctype html>
<html lang="en" class="scroll-smooth"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${label}</title><link rel="icon" href="${favicon}">
${fontLinks}
<script type="importmap">{"imports":{
"react":"https://esm.sh/react@19.0.1",
"react/jsx-runtime":"https://esm.sh/react@19.0.1/jsx-runtime?external=react",
"react-dom/client":"https://esm.sh/react-dom@19.0.1/client?external=react",
"lucide-react":"https://esm.sh/lucide-react@0.546.0?external=react"
}}</script>
<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4.1.14" onerror="window.__mintPreviewStyleFailed=true"></script>
<style type="text/tailwindcss">${css}</style>
</head><body class="bg-slate-50 text-slate-800 antialiased selection:bg-emerald-500 selection:text-white">
<div id="preview-status" style="font:14px Arial,sans-serif;padding:20px;background:#fff;color:#14253b">Loading the original website preview. Internet access is needed for React, Lucide, Tailwind and the original fonts. This review file does not submit service requests.</div>
<div id="root"></div>
<script>
// Review-only guard: never send or fabricate a submission in either comparison version.
document.addEventListener('submit',function(e){e.preventDefault();e.stopImmediatePropagation();alert('Preview only. No service request has been sent.');},true);
</script>
<script type="module">
const showError = error => {
 const notice = document.getElementById('preview-status');
 notice.style.display='block';
 notice.textContent='Preview dependencies could not load. Open this file with internet access in Chrome or Edge, or run npm install followed by npm run dev in Cursor. No request has been sent.';
 console.error('Preview dependency error',error);
};
const definitions={${definitions}};
try {
 if(window.__mintPreviewStyleFailed)throw new Error('Tailwind could not load');
 const [react,jsxRuntime,dom,lucide]=await Promise.all([import('react'),import('react/jsx-runtime'),import('react-dom/client'),import('lucide-react')]);
 const external={'react':react.default||react,'react/jsx-runtime':jsxRuntime,'react-dom/client':dom,'lucide-react':lucide};
 const cache={};
 function requireModule(id, from='') {
  if (id.endsWith('.css')) return {};
  if (external[id]) return external[id];
  if (id.startsWith('.')) {
   const parts=from.split('/');parts.pop();
   for (const p of id.split('/')) { if(p==='..')parts.pop();else if(p!=='.')parts.push(p); }
   id=parts.join('/');
  }
  id=id.replace(/\\.tsx?$/,'');
  if(cache[id])return cache[id].exports;
  if(!definitions[id])throw new Error('Missing preview module '+id);
  const module={exports:{}};cache[id]=module;
  definitions[id](dep=>requireModule(dep,id),module,module.exports);
  return module.exports;
 }
 requireModule('src/main');
 document.getElementById('preview-status').style.display='none';
} catch(error) {showError(error);}
</script></body></html>`;
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, html);
  console.log('Review HTML: ' + outputPath);
  return html;
}
module.exports = { createPreview };
if (require.main === module) {
 const root=path.resolve(__dirname,'..');
 createPreview(root,path.resolve(process.argv[2]||path.join(root,'review','interactive-preview.html')),'Mint Response LLC — Original + requested changes');
}

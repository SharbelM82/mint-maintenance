import type { Plugin } from 'vite';
import { handleRequest } from '../worker/service-request.mjs';

// The same server handler runs in Vite dev/preview and in Cloudflare Pages.
export function mintApiPlugin(env: Record<string, string>): Plugin {
  const middleware = async (req: any, res: any, next: () => void) => {
    if (!req.url?.startsWith('/api/')) return next();
    const chunks: Uint8Array[] = [];
    let size = 0;
    try {
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 16384) {
          res.writeHead(413, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
          res.end(JSON.stringify({ ok: false, code: 'BODY_TOO_LARGE' }));
          return;
        }
        chunks.push(chunk);
      }
      const headers = new Headers();
      for (const name of ['content-type', 'content-length', 'origin']) {
        if (typeof req.headers[name] === 'string') headers.set(name, req.headers[name]);
      }
      const request = new Request(`http://${req.headers.host}${req.url}`, {
        method: req.method,
        headers,
        body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks).toString('utf8'),
      });
      const response = await handleRequest(request, env);
      res.statusCode = response.status;
      response.headers.forEach((value: string, key: string) => res.setHeader(key, value));
      res.end(await response.text());
    } catch {
      if (!res.headersSent) res.writeHead(500, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify({ ok: false, code: 'SERVER_ERROR' }));
    }
  };
  return {
    name: 'mint-service-request-api',
    configureServer(server) { server.middlewares.use(middleware); },
    configurePreviewServer(server) { server.middlewares.use(middleware); },
  };
}

import React from 'react';
import { Shield, CheckCircle2, ArrowRight, PhoneCall, MapPin, Zap, Wind, Droplets, Wrench, Building2, Clock } from 'lucide-react';
import { COMPANY_INFO } from '../data/facilityData';
import { MintLogo } from './MintLogo';

interface HeroProps {
  onRequestService: () => void;
  onContactClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onRequestService, onContactClick }) => {
  return (
    <section id="home" className="relative bg-slate-900 text-white overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
      {/* Background Architectural Grid Pattern */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
          <defs>
            <pattern id="facility-grid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 48 0 L 0 0 0 48" fill="none" stroke="#10b981" strokeWidth="0.8" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#facility-grid)" />
        </svg>
      </div>

      {/* Subtle Ambient Radial Glow - Brighter and more illuminated */}
      <div className="absolute top-0 right-1/4 w-[28rem] h-[28rem] bg-emerald-500/25 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-10 w-96 h-96 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Main Hero Copy (Left Column) */}
          <div className="lg:col-span-7 space-y-8">
            {/* Location Badge with Official Mint Logo */}
            <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-slate-800/95 border border-emerald-500/40 text-emerald-300 text-xs sm:text-sm font-bold tracking-wide shadow-md shadow-emerald-500/20">
              <MintLogo variant="icon" size="sm" />
              <span>Mint Response Commercial Maintenance</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-4">
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.12]">
                Your Trusted Commercial Facility Management Partner
              </h1>

              {/* Exact Description from Prompt */}
              <p className="text-lg sm:text-xl text-slate-300 font-normal leading-relaxed max-w-2xl">
                {COMPANY_INFO.heroDescription}
              </p>
            </div>

            {/* Core Value Statement / Motto Banner */}
            <div className="p-4 rounded-xl bg-slate-800/90 border border-emerald-500/30 backdrop-blur-xs flex items-center gap-3.5 shadow-xs shadow-emerald-500/10">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/25 text-emerald-300 flex items-center justify-center shrink-0">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-slate-300 font-semibold">
                  Commercial Guarantee
                </p>
                <p className="text-base sm:text-lg font-bold text-emerald-300">
                  {COMPANY_INFO.motto}
                </p>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                id="hero-request-service-btn"
                onClick={onRequestService}
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-base shadow-xl shadow-emerald-500/30 hover:shadow-emerald-500/50 transition-all cursor-pointer active:scale-[0.98]"
              >
                <span>Request a Service</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-contact-btn"
                onClick={onContactClick}
                className="inline-flex items-center justify-center gap-2 px-7 py-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 hover:border-emerald-500/40 font-semibold text-base transition-all cursor-pointer"
              >
                <PhoneCall className="w-4 h-4 text-emerald-400" />
                <span>Contact Us</span>
              </button>
            </div>

          </div>

          {/* Architectural Commercial Spec Card (Right Column) */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl bg-slate-800/95 border border-slate-700/80 p-6 sm:p-7 shadow-2xl backdrop-blur-sm">
              
              {/* Card Header */}
              <div className="flex items-center justify-between pb-5 border-b border-slate-700">
                <div className="flex items-center gap-3.5">
                  <div className="p-2 rounded-xl bg-slate-900 border border-emerald-500/40 shrink-0 shadow-sm shadow-emerald-500/20">
                    <MintLogo variant="icon" size="md" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-300">
                      Commercial Facility
                    </span>
                    <h3 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                      Single-Source Facility Care
                    </h3>
                  </div>
                </div>
                <span className="px-3 py-1 rounded text-xs font-bold bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 shrink-0">
                  Ready to Deploy
                </span>
              </div>

              {/* 5 Core Trades Showcase */}
              <div className="py-5 space-y-3.5">
                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-700/50 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-sky-500/25 text-sky-300 flex items-center justify-center font-bold">
                      <Wind className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">HVAC Maintenance & Repairs</p>
                      <p className="text-xs text-slate-400">Commercial units, filters, thermostats</p>
                    </div>
                  </div>
                  <span className="text-xs text-emerald-400 font-medium">Preventive</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-700/50 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-cyan-500/25 text-cyan-300 flex items-center justify-center font-bold">
                      <Droplets className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">Commercial Plumbing</p>
                      <p className="text-xs text-slate-400">Restroom banks, leaks, non-excavation drains</p>
                    </div>
                  </div>
                  <span className="text-xs text-cyan-400 font-medium">Certified</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-700/50 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-amber-500/25 text-amber-300 flex items-center justify-center font-bold">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">Electrical Systems</p>
                      <p className="text-xs text-slate-400">LED retrofits, panels, code compliance</p>
                    </div>
                  </div>
                  <span className="text-xs text-amber-400 font-medium">Safety-First</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-700/50 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-emerald-500/25 text-emerald-300 flex items-center justify-center font-bold">
                      <Wrench className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">Handyman & Upkeep</p>
                      <p className="text-xs text-slate-400">Doors, hardware, ceiling tiles, drywall</p>
                    </div>
                  </div>
                  <span className="text-xs text-emerald-400 font-medium">Routine</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-700/50 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-purple-500/25 text-purple-300 flex items-center justify-center font-bold">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">Commercial Renovations</p>
                      <p className="text-xs text-slate-400">Tenant improvements & interior remodeling</p>
                    </div>
                  </div>
                  <span className="text-xs text-purple-400 font-medium">Interior Only</span>
                </div>
              </div>

              {/* Card Footer Note */}
              <div className="pt-4 border-t border-slate-700/80 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-400" />
                  Fast triage & responsive dispatch
                </span>
                <button
                  onClick={onRequestService}
                  className="text-emerald-400 hover:text-emerald-300 font-semibold underline underline-offset-2"
                >
                  Schedule Initial Scope →
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

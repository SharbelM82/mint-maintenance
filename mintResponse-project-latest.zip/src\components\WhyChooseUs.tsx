import React from 'react';
import { Zap, Briefcase, CheckCircle, Layers, ArrowUpRight } from 'lucide-react';
import { WHY_CHOOSE_US } from '../data/facilityData';

interface WhyChooseUsProps {
  onRequestService: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onRequestService }) => {
  const icons = [Zap, Briefcase, CheckCircle, Layers];

  return (
    <section id="why-us" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300/60 text-xs font-bold uppercase tracking-wider">
            Value Proposition
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Why Choose Mint Response?
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Built from the ground up to solve the specific operational, scheduling, and reliability pain points commercial property managers.
          </p>
        </div>

        {/* 4 Feature Columns / Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {WHY_CHOOSE_US.map((item, index) => {
            const Icon = icons[index];
            return (
              <div
                key={item.title}
                className="bg-white rounded-xl border border-slate-200/90 p-7 shadow-xs hover:shadow-md hover:border-emerald-500/50 transition-all group flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-6 group-hover:bg-emerald-500 group-hover:text-white group-hover:shadow-md group-hover:shadow-emerald-500/25 transition-all">
                    <Icon className="w-6 h-6" />
                  </div>

                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded">
                    {item.metric}
                  </span>

                  <h3 className="font-display text-xl font-bold text-slate-900 mt-3 mb-2.5">
                    {item.title}
                  </h3>

                  <p className="text-slate-600 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span className="font-medium text-slate-700">{item.highlight}</span>
                  <span className="text-emerald-500 font-bold opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                    Learn <ArrowUpRight className="w-3.5 h-3.5 ml-0.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Fast Action Banner */}
        <div className="mt-14 p-6 sm:p-8 rounded-2xl bg-slate-900 text-white flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-800">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-xl font-bold text-white">
              Tired of juggling 5 different independent repair contractors?
            </h4>
            <p className="text-slate-300 text-sm">
              Consolidate your facility maintenance under one accountable, responsive partner.
            </p>
          </div>
          <button
            onClick={onRequestService}
            className="shrink-0 px-6 py-3.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-sm shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 transition-all cursor-pointer active:scale-[0.98]"
          >
            Request Facility Assessment
          </button>
        </div>

      </div>
    </section>
  );
};

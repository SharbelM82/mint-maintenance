# Verification record — September 6, 2026

## Completed

* 24 Node tests passed: 16 server-handler tests and 8 content/preservation tests. Provider calls were mocked; no inquiries were sent. See TEST_RESULTS.txt.
* 17 TypeScript/TSX files transpiled without syntax diagnostics using the locally available TypeScript 5.8.3 compiler. This is a syntax check, not a dependency-resolved type check.
* Ten protected original files match their SHA-256 hashes, including the stylesheet, original HTML metadata, App/main, maintenance-planner component and all three SVG assets.
* An AST comparison of JSX className/style attributes in all 11 original component files found no added or changed attribute values. Requested block removals are allowed. See LAYOUT_ATTRIBUTE_AUDIT.json. This is a code-level layout-preservation check, not proof of rendered visual equivalence.
* Inline JavaScript syntax in both generated review HTML files passed Node syntax checks.
* Six controls in the before/after review shell passed Chromium checks: initial version, original/edited source selection, toggle state, 390-pixel width control and the unavailable-content notice. External dependencies were blocked during this shell test; the React website itself was NOT visually rendered or verified. See PREVIEW_WRAPPER_TEST.json.

## Not completed — must run before publication

Npm/CDN downloads were unavailable in the preparation environment. Therefore npm install, dependency-resolved TypeScript checking, the actual Vite production build, the Cloudflare build/deployment and a full desktop/mobile visual check were not completed. No production dist ZIP is claimed or supplied. No package-lock.json was fabricated; generate and commit the real lockfile after npm install in Cursor.

The supplied interactive review is generated from the actual TSX sources. It uses public CDNs for its runtime and styling plus the original font stylesheet. It is not the deployable production build and requires internet access. Both versions deliberately disable submission. A blocked CDN can prevent rendering; use the local Vite preview as the authoritative production-configuration review after installation.

No live Formspree endpoint, email notification, real inbox receipt, domain ownership, DNS record or operational capability has been verified. A real provider setup and owner-approved end-to-end test are required. Unit test acceptance is not a delivery guarantee.

## Required local sequence

```sh
npm install
npm run verify
npm run dev
```

Then review the actual website at http://127.0.0.1:3000. After the build, npm run preview serves dist on http://127.0.0.1:4173 with the same API adapter. Inspect every section, buttons, service filters, menus and the form; check desktop and mobile. Read UNCHANGED_ITEMS.md before approving content. Unrelated inherited frontend behaviors were not silently changed.

## Publication status

Source handoff only. No hosting/GitHub accounts were created or changed and nothing was deployed. The review documents and source references are outside public/ and are not inputs to the published asset directory.

import React, { useState } from 'react';
import { 
  Wind, 
  Droplets, 
  Zap, 
  Wrench, 
  Building2, 
  CheckCircle2, 
  ArrowRight, 
  AlertCircle,
  FileCheck2,
  CalendarCheck
} from 'lucide-react';
import { CORE_SERVICES } from '../data/facilityData';
import { ServiceCategory } from '../types';

interface ServicesSectionProps {
  onSelectServiceForRequest: (serviceId: ServiceCategory) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectServiceForRequest }) => {
  const [activeTab, setActiveTab] = useState<ServiceCategory | 'all'>('all');

  const getServiceIcon = (id: ServiceCategory) => {
    switch (id) {
      case 'hvac':
        return <Wind className="w-5 h-5" />;
      case 'plumbing':
        return <Droplets className="w-5 h-5" />;
      case 'electrical':
        return <Zap className="w-5 h-5" />;
      case 'handyman':
        return <Wrench className="w-5 h-5" />;
      case 'renovation':
        return <Building2 className="w-5 h-5" />;
      default:
        return <Wrench className="w-5 h-5" />;
    }
  };

  const visibleServices = CORE_SERVICES.filter(s => s.id !== 'renovation');
  const filteredServices = activeTab === 'all' 
    ? visibleServices 
    : visibleServices.filter(s => s.id === activeTab);

  return (
    <section id="services" className="py-24 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title & Description (Exact text from prompt) */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300/60 text-xs font-bold uppercase tracking-wider">
            Commercial Facility Services
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Our Core Services
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Mint Response offers comprehensive facility maintenance and improvement services designed specifically for commercial properties.
          </p>
        </div>

        {/* Trade Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-14">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All {visibleServices.length} Core Services
          </button>

          {visibleServices.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveTab(s.id)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all cursor-pointer ${
                activeTab === s.id
                  ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/25'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {getServiceIcon(s.id)}
              <span>{s.title}</span>
            </button>
          ))}
        </div>

        {/* Services Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="bg-slate-50/70 border border-slate-200/90 rounded-2xl p-7 flex flex-col justify-between hover:bg-white hover:shadow-lg hover:border-emerald-500/40 transition-all duration-200 group"
            >
              <div>
                {/* Icon & Title Header */}
                <div className="flex items-start justify-between gap-4 mb-5">
                  <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 text-emerald-500 flex items-center justify-center shadow-xs group-hover:bg-emerald-500 group-hover:text-white group-hover:shadow-md group-hover:shadow-emerald-500/25 transition-all">
                    {getServiceIcon(service.id)}
                  </div>
                  <span className="text-[11px] font-semibold text-slate-500 bg-white border border-slate-200 px-2.5 py-1 rounded-full">
                    Commercial Grade
                  </span>
                </div>

                <h3 className="font-display text-2xl font-bold text-slate-900 mb-1">
                  {service.title}
                </h3>
                <p className="text-xs font-bold uppercase tracking-wider text-emerald-600 mb-4">
                  {service.tagline}
                </p>

                {/* Main Paragraph */}
                <p className="text-slate-600 text-sm leading-relaxed mb-6">
                  {service.description}
                </p>

                {/* Renovation Note Banner if present */}
                {service.note && (
                  <div className="mb-6 p-3.5 rounded-lg bg-amber-50 border border-amber-200/80 text-amber-900 text-xs font-medium flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>{service.note}</span>
                  </div>
                )}

                {/* Services Include Checklist */}
                <div className="pt-4 border-t border-slate-200/80">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-3 flex items-center gap-1.5">
                    <FileCheck2 className="w-3.5 h-3.5 text-emerald-500" />
                    Services Include:
                  </h4>
                  <ul className="space-y-2">
                    {service.includedServices.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span className="font-medium">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-8 pt-5 border-t border-slate-200/80">
                <button
                  onClick={() => onSelectServiceForRequest(service.id)}
                  className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-lg bg-white border border-slate-300 text-slate-800 font-bold text-xs hover:bg-emerald-500 hover:text-white hover:border-emerald-500 hover:shadow-md hover:shadow-emerald-500/20 transition-all shadow-2xs group/btn cursor-pointer"
                >
                  <CalendarCheck className="w-3.5 h-3.5 text-emerald-500 group-hover/btn:text-white" />
                  <span>Request {service.title}</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Consolidated Service Assurance Banner */}
        <div className="mt-16 rounded-2xl bg-emerald-50 border border-emerald-300 p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-lg font-bold text-emerald-950">
              Need Multi-Trade Commercial Support or Preventive Maintenance?
            </h4>
            <p className="text-emerald-800 text-sm max-w-2xl">
              Mint Response tailors ongoing maintenance plans combining seasonal HVAC inspections, routine plumbing checks, and monthly handyman sweeps.
            </p>
          </div>
          <button
            onClick={() => onSelectServiceForRequest('comprehensive')}
            className="shrink-0 px-6 py-3.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-sm shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 transition-all cursor-pointer active:scale-[0.98]"
          >
            Customized Service Proposal
          </button>
        </div>

      </div>
    </section>
  );
};

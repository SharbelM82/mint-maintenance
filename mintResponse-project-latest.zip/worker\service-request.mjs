/**
 * Cloudflare Pages advanced-mode worker. No browser API key or fake receipt.
 * Set CONTACT_FORM_ENDPOINT in the host's SERVER environment after creating
 * and verifying the owner's Formspree form. No customer data is logged here.
 */
const MAX_BODY_BYTES = 16384;
const SERVICES = new Set(['hvac', 'plumbing', 'electrical', 'handyman', 'renovation', 'comprehensive']);
const PRIORITIES = new Set(['emergency', 'urgent', 'scheduled']);
const PROPERTY_TYPES = new Set([
  'Office Buildings', 'Retail Centers', 'Warehouses', 'Industrial Facilities',
  'Healthcare Facilities', 'Restaurants', 'Educational Facilities',
  'Commercial Properties & Property Management Companies',
]);

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...extraHeaders,
    },
  });
}

async function readLimitedJSON(request) {
  const length = request.headers.get('content-length');
  if (length && (!/^\d+$/.test(length) || Number(length) > MAX_BODY_BYTES)) {
    throw Object.assign(new Error('oversized'), { status: 413 });
  }
  const reader = request.body?.getReader();
  if (!reader) throw new Error('empty');
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_BODY_BYTES) {
        await reader.cancel();
        throw Object.assign(new Error('oversized'), { status: 413 });
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
}

export function validateSubmission(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null;
  const limits = {
    fullName: [1, 120], businessName: [1, 180], phone: [7, 40],
    email: [3, 254], propertyType: [1, 120], locationCity: [0, 160],
    primaryService: [1, 30], urgency: [1, 20], projectScope: [1, 5000],
  };
  const result = {};
  for (const [key, [min, max]] of Object.entries(limits)) {
    if (typeof input[key] !== 'string') return null;
    const value = input[key].trim();
    if (value.length < min || value.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)) return null;
    if (key !== 'projectScope' && /[\r\n]/.test(value)) return null;
    result[key] = value;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(result.email)) return null;
  if (!/^[+()\d\s.\-xext]+$/i.test(result.phone) || result.phone.replace(/\D/g, '').length < 7) return null;
  if (!SERVICES.has(result.primaryService) || !PRIORITIES.has(result.urgency) || !PROPERTY_TYPES.has(result.propertyType)) return null;
  return result;
}

/** Injectable fetch/ID functions let tests exercise all paths without sending email. */
export async function handleRequest(request, env = {}, dependencies = {}) {
  const url = new URL(request.url);
  if (url.pathname !== '/api/service-request') return json({ ok: false, code: 'NOT_FOUND' }, 404);
  if (request.method !== 'POST') return json({ ok: false, code: 'METHOD_NOT_ALLOWED' }, 405, { Allow: 'POST' });
  // Origin checks prevent cross-site browser posts, not direct automated spam.
  if (request.headers.get('origin') !== url.origin) return json({ ok: false, code: 'ORIGIN_REJECTED' }, 403);
  if (request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json') {
    return json({ ok: false, code: 'JSON_REQUIRED' }, 415);
  }
  let input;
  try { input = await readLimitedJSON(request); }
  catch (error) { return json({ ok: false, code: error.status === 413 ? 'BODY_TOO_LARGE' : 'INVALID_JSON' }, error.status === 413 ? 413 : 400); }
  if (input && typeof input === 'object' && input.companyWebsite) return json({ ok: false, code: 'REQUEST_REJECTED' }, 400);
  const submission = validateSubmission(input);
  if (!submission) return json({ ok: false, code: 'INVALID_FIELDS' }, 400);
  // Fail closed until the owner configures a real form. No example destination.
  if (typeof env.CONTACT_FORM_ENDPOINT !== 'string' || !/^https:\/\/formspree\.io\/f\/[a-z0-9]+$/.test(env.CONTACT_FORM_ENDPOINT)) {
    return json({ ok: false, code: 'FORM_NOT_CONFIGURED' }, 503);
  }
  const fetcher = dependencies.fetch ?? globalThis.fetch;
  const uuid = dependencies.randomUUID ?? (() => crypto.randomUUID());
  const now = dependencies.now ?? (() => new Date().toISOString());
  const id = `MR-${uuid()}`;
  const submittedAt = now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), dependencies.timeoutMs ?? 10000);
  try {
    const response = await fetcher(env.CONTACT_FORM_ENDPOINT, {
      method: 'POST',
      redirect: 'error',
      headers: {
        'Content-Type': 'application/json', Accept: 'application/json',
        Origin: url.origin, Referer: `${url.origin}/`,
      },
      body: JSON.stringify({
        ...submission,
        reference: id,
        submittedAt,
        _subject: `Mint Response Service Request ${id}`,
        _gotcha: '',
      }),
      signal: controller.signal,
    });
    // A redirect, CAPTCHA challenge, HTML page or ambiguous 2xx is not a receipt.
    const body = response.headers.get('content-type')?.includes('application/json')
      ? await response.json().catch(() => null) : null;
    if (!response.ok || body?.ok !== true || body?.errors || body?.error) {
      return json({ ok: false, code: response.status === 429 ? 'RATE_LIMITED' : 'DELIVERY_NOT_CONFIRMED' }, response.status === 429 ? 429 : 502);
    }
    return json({ ok: true, id, submittedAt }, 201);
  } catch {
    // A timeout can occur after provider acceptance. Do not auto-retry.
    return json({ ok: false, code: 'DELIVERY_NOT_CONFIRMED' }, 502);
  } finally {
    clearTimeout(timeout);
  }
}

export default {
  async fetch(request, env) {
    if (new URL(request.url).pathname.startsWith('/api/')) return handleRequest(request, env);
    return env.ASSETS.fetch(request);
  },
};

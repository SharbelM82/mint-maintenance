import React from 'react';

export interface MintLogoProps {
  variant?: 'full' | 'horizontal' | 'icon' | 'mark';
  theme?: 'light' | 'dark';
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
}

export const MintLogo: React.FC<MintLogoProps> = ({
  variant = 'horizontal',
  theme = 'light',
  className = '',
  size = 'md',
  showSubtitle = true,
}) => {
  const isDark = theme === 'dark';
  
  // Exact colors from official Mint Logo.jpg
  const brandGreen = '#337B38';
  const brandBlack = isDark ? '#FFFFFF' : '#0A0A0A';
  const buildingLeft = isDark ? '#334155' : '#141414';
  const buildingCenterLeft = isDark ? '#1E293B' : '#1E1E1E';
  const buildingFacade = isDark ? '#0F172A' : '#FFFFFF';
  const buildingRight = isDark ? '#334155' : '#141414';
  const leftMPillar = isDark ? '#F8FAFC' : '#0A0A0A';

  // The Emblem SVG component exactly reproducing Mint Logo.jpg
  const renderEmblem = (emblemSize: number = 64) => (
    <svg
      viewBox="0 0 300 300"
      width={emblemSize}
      height={emblemSize}
      className="shrink-0 transition-transform duration-200 group-hover:scale-105"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <g>
        {/* Circular Green Crescent / Orbital Arc */}
        <path
          d="M 62 165 C 62 95, 102 44, 150 44 C 205 44, 245 95, 245 158 C 245 190, 235 212, 218 226 C 228 214, 234 192, 234 165 C 234 108, 198 56, 150 56 C 108 56, 75 102, 74 165 Z"
          fill={brandGreen}
        />
        <path
          d="M 62 165 C 62 88, 102 36, 150 36 C 210 36, 252 90, 252 165 C 252 205, 235 228, 224 235 C 238 225, 245 200, 245 165 C 245 95, 205 44, 150 44 C 98 44, 66 95, 62 165 Z"
          fill={brandGreen}
        />

        {/* Commercial Buildings Silhouette (Behind M) */}
        {/* Left Skyscraper */}
        <polygon points="100,125 125,108 125,195 100,195" fill={buildingLeft} />

        {/* Center Tall Skyscraper */}
        {/* Left Shadow Facet */}
        <polygon points="125,108 152,70 152,195 125,195" fill={buildingCenterLeft} />
        
        {/* Right Facet with White/light facade */}
        <polygon
          points="152,70 184,94 184,175 152,195"
          fill={buildingFacade}
          stroke={isDark ? '#475569' : '#0A0A0A'}
          strokeWidth="1.2"
          strokeLinejoin="round"
        />

        {/* Architectural Windows (Solid Green on facade) */}
        <g fill={brandGreen}>
          {/* Row 1 */}
          <rect x="157" y="92" width="5.5" height="11" rx="0.5" />
          <rect x="168" y="97" width="5.5" height="11" rx="0.5" />

          {/* Row 2 */}
          <rect x="157" y="108" width="5.5" height="11" rx="0.5" />
          <rect x="168" y="113" width="5.5" height="11" rx="0.5" />

          {/* Row 3 */}
          <rect x="157" y="124" width="5.5" height="11" rx="0.5" />
          <rect x="168" y="129" width="5.5" height="11" rx="0.5" />

          {/* Row 4 */}
          <rect x="157" y="140" width="5.5" height="11" rx="0.5" />
          <rect x="168" y="145" width="5.5" height="11" rx="0.5" />
        </g>

        {/* Right Skyscraper */}
        <polygon points="184,115 212,130 212,185 184,175" fill={buildingRight} />

        {/* Stylized M */}
        {/* Left Pillar (Solid Black) */}
        <polygon points="84,136 108,120 108,220 84,220" fill={leftMPillar} />

        {/* Green Dynamic Chevron & Swooping Right Arm */}
        <path
          d="M 108 120 
             L 150 174 
             L 192 120 
             L 216 120 
             L 216 220 
             C 224 218, 238 214, 245 205
             C 238 218, 222 225, 206 225
             L 194 220 
             L 194 154 
             L 150 206 
             L 108 152 
             Z"
          fill={brandGreen}
        />
      </g>
    </svg>
  );

  // Icon only
  if (variant === 'icon' || variant === 'mark') {
    const iconSizes = { sm: 40, md: 54, lg: 72, xl: 96 };
    return (
      <div className={`inline-flex items-center justify-center ${className}`}>
        <img
          src="/logo%20only%20new.svg"
          alt="Mint Response logo"
          width={iconSizes[size]}
          height={iconSizes[size]}
          className="shrink-0 transition-transform duration-200 group-hover:scale-105"
        />
      </div>
    );
  }

  // Full vertical layout (emblem + wordmark; LLC lockup omitted per owner instruction)
  if (variant === 'full') {
    return (
      <div
        className={`flex flex-col items-center text-center select-none ${className}`}
        aria-label="Mint Response Logo"
      >
        <div className="mb-2">
          <img
            src="/logo%20only%20new.svg"
            alt="Mint Response logo"
            width={size === 'xl' ? 180 : size === 'lg' ? 140 : size === 'md' ? 110 : 80}
            height={size === 'xl' ? 180 : size === 'lg' ? 140 : size === 'md' ? 110 : 80}
            className="shrink-0"
          />
        </div>

        <div
          style={{ color: brandBlack }}
          className={`font-display font-black tracking-[0.16em] uppercase ${
            size === 'xl' ? 'text-5xl' : size === 'lg' ? 'text-4xl' : size === 'md' ? 'text-3xl' : 'text-2xl'
          }`}
        >
          MINT
        </div>

        <div
          style={{ color: isDark ? '#E2E8F0' : '#0A0A0A' }}
          className={`font-sans font-medium tracking-[0.2em] ${
            size === 'xl' ? 'text-2xl mt-1' : size === 'lg' ? 'text-xl mt-1' : size === 'md' ? 'text-lg mt-0.5' : 'text-base mt-0.5'
          }`}
        >
          Response
        </div>
      </div>
    );
  }

  // Horizontal layout (for Navbar, Headers, Footers)
  return (
    <div
      className={`flex items-center gap-3 select-none ${className}`}
      aria-label="Mint Response Logo"
    >
      <div className="shrink-0 relative">
        <img
          src="/logo%20only%20new.svg"
          alt="Mint Response logo"
          className={`w-auto object-contain ${
            size === 'xl' ? 'h-20' : size === 'lg' ? 'h-16' : size === 'md' ? 'h-14' : 'h-12'
          }`}
        />
      </div>
      <div className="flex flex-col justify-center">
        <div className="flex items-baseline gap-2">
          <span
            style={{ color: brandBlack }}
            className={`font-display font-black tracking-tight leading-none ${
              size === 'xl'
                ? 'text-3xl'
                : size === 'lg'
                ? 'text-2xl sm:text-3xl'
                : size === 'md'
                ? 'text-xl sm:text-2xl'
                : 'text-lg'
            }`}
          >
            MINT
          </span>
          <span
            style={{ color: isDark ? '#E2E8F0' : '#0A0A0A' }}
            className={`font-sans font-medium tracking-normal leading-none ${
              size === 'xl'
                ? 'text-2xl'
                : size === 'lg'
                ? 'text-xl sm:text-2xl'
                : size === 'md'
                ? 'text-lg sm:text-xl'
                : 'text-base'
            }`}
          >
            Response
          </span>
        </div>
        {showSubtitle && (
          <p
            className={`font-medium tracking-wide whitespace-nowrap mt-1 ${
              isDark ? 'text-slate-400' : 'text-slate-500'
            } ${
              size === 'xl'
                ? 'text-xs'
                : size === 'lg'
                ? 'text-[10px]'
                : 'text-[11px]'
            }`}
          >
            Commercial Facility Management
          </p>
        )}
      </div>
    </div>
  );
};

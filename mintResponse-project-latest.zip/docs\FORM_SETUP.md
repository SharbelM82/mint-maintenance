# Activate real request delivery

The endpoint is intentionally empty in this handoff. Until configured, the server fails closed with `FORM_NOT_CONFIGURED`; no success ticket is shown. The review HTML files never submit anything even when internet is available.

## Configuration

Create a Formspree form under an owner-controlled account. Set its recipient to the real monitored Mint inbox, complete verification and confirm its dashboard records submissions. Copy its real public endpoint, of the form `https://formspree.io/f/<your-form-id>`.

In local development, copy `.env.example` to `.env.local`, set `CONTACT_FORM_ENDPOINT` and restart `npm run dev`. This is a SERVER setting; do not name it VITE_CONTACT_FORM_ENDPOINT. In Cloudflare Pages, set the same variable in the server environment for the relevant deployment environment. Configure preview and production separately. Do not commit real environment files.

The adapter preserves the existing form design and does not add a CAPTCHA widget. Configure the provider appropriately for a server-to-server JSON submission. An enabled CAPTCHA requirement without a supplied token may reject the request; this worker correctly returns a failure instead of a false receipt. If CAPTCHA is needed, approve the necessary frontend addition rather than pretending it is already present. Provider filtering, domain restrictions and host-side rate limiting should be reviewed. The hidden honeypot and same-origin check alone do not stop all automated abuse.

## Required live acceptance test

Run one owner-approved, clearly labeled test from the actual preview/production domain. Confirm both the saved Formspree submission and the notification in the real inbox. Verify the MR reference, reply-to address, selected service, facility type, location, urgency and scope. Test a rejected/failed submission and confirm no receipt appears and the inputs remain. Inspect provider spam and CAPTCHA handling as well as normal success.

A provider acknowledgement is not proof that a technician was dispatched or a human has begun reviewing. The original confirmation wording was retained at the user's instruction; operational review must support that wording. This adapter is not a work-order management system.

Timeouts can occur after a provider has accepted a request. The client does not automatically retry; users are told to check before resubmitting. The provider may otherwise record duplicates. The MR reference is a traceable submission/email reference, not a database-backed dispatch ticket.

No live delivery was tested in the preparation environment and no Formspree account was connected.

## Technical references (checked September 6, 2026)

Formspree submission documentation: https://help.formspree.io/articles/building-your-form/submit-forms-with-javascript-ajax/

Formspree CAPTCHA settings: https://help.formspree.io/articles/form-and-project-settings/recaptcha-settings/

Cloudflare advanced-mode worker: https://developers.cloudflare.com/pages/functions/advanced-mode/

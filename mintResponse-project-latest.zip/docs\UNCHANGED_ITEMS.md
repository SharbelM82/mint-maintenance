# Items intentionally not changed

These are present in the ORIGINAL export but were not selected for removal/rewrite in the user's screenshot instructions. They are listed for transparency, not approval to change them.

## Remaining Kansas references

Owner-directed September 9 edits removed the remaining customer-facing Kansas wording. A developer-only comment in `src/App.tsx` still mentions Kansas Coverage and was left unchanged because it is not rendered. Historical notes in this documentation still describe the earlier Kansas-scoped screenshot edits.

## Remaining renovations references

The small hero renovations row, descriptions that mention renovations, the Why Us description, the original five-contractor banner, the footer service link, the contact-service dropdown, and the form's excavation note remain. The footer's Note line was removed on owner instruction. Only the marked detailed Core Services card and its filter were removed from the services grid.

## Items requiring owner decisions before public launch

The header has no phone. Contact and footer display `479-341-5787`. No monitored inbox has been verified here. Existing licensing, trademark, OSHA, performance, guaranteed-accountability, urgency and dispatch claims have not been independently verified or rewritten. No legal/privacy copy was added without instruction; assess the actual contact-data processors before enabling live submissions.

The literal deletion of `facing Kansas` leaves an awkward sentence. See CHANGE_LOG.md.

The desktop Home / About Us / Services / Industries / Why Us / Contact links now show from the `md` breakpoint so they remain visible in typical preview widths. The hamburger menu is limited to below `md`, matching the dropdown. The original maintenance planner also computes a summary that App.tsx does not pass to the request form. That unrelated frontend behavior was not silently changed under the permission to fix backend bugs. It should not be represented as tested/fixed.

## No redesign

No new pages, careers section, stock/generated photographs, different headline, different business name, broker/subcontracting copy, fonts or palette were added. The original stylesheet and all supplied SVG files remain byte-for-byte unchanged.

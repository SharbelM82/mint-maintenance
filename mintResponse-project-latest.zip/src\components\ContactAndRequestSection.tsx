import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  Clock, 
  MapPin, 
  ShieldAlert, 
  Send, 
  CheckCircle, 
  Copy, 
  AlertTriangle, 
  Building,
  Wrench,
  FileText
} from 'lucide-react';
import { COMPANY_INFO, CORE_SERVICES, INDUSTRIES_SERVED } from '../data/facilityData';
import { ServiceCategory, UrgencyLevel, ServiceRequestSubmission } from '../types';
import { MintLogo } from './MintLogo';

interface ContactAndRequestSectionProps {
  preselectedService?: ServiceCategory | null;
  preselectedPropertyType?: string | null;
}

export const ContactAndRequestSection: React.FC<ContactAndRequestSectionProps> = ({
  preselectedService,
  preselectedPropertyType,
}) => {
  // Form state
  const [fullName, setFullName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [propertyType, setPropertyType] = useState<string>(preselectedPropertyType || INDUSTRIES_SERVED[0].name);
  const [locationCity, setLocationCity] = useState('');
  const [primaryService, setPrimaryService] = useState<ServiceCategory>(preselectedService || 'hvac');
  const [urgency, setUrgency] = useState<UrgencyLevel>('urgent');
  const [projectScope, setProjectScope] = useState('');
  const [companyWebsite, setCompanyWebsite] = useState('');

  // UI state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedTicket, setSubmittedTicket] = useState<ServiceRequestSubmission | null>(null);
  const [copiedTicket, setCopiedTicket] = useState(false);

  useEffect(() => {
    if (preselectedService) {
      setPrimaryService(preselectedService);
    }
  }, [preselectedService]);

  useEffect(() => {
    if (preselectedPropertyType) {
      setPropertyType(preselectedPropertyType);
    }
  }, [preselectedPropertyType]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    if (!fullName.trim() || !businessName.trim() || !phone.trim() || !email.trim() || !projectScope.trim()) return;
    if (window.location.protocol === 'file:') {
      window.alert('This is a preview. No request has been sent. Please contact ' + COMPANY_INFO.email + '.');
      return;
    }
    setIsSubmitting(true);
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 20000);
    try {
      const fields = {
        fullName: fullName.trim(), businessName: businessName.trim(), phone: phone.trim(),
        email: email.trim(), propertyType, locationCity: locationCity.trim(),
        primaryService, urgency, projectScope: projectScope.trim(),
      };
      const response = await fetch('/api/service-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ ...fields, companyWebsite }),
        signal: controller.signal,
      });
      const result = await response.json().catch(() => null);
      if (!response.ok || result?.ok !== true || typeof result.id !== 'string' ||
          !/^MR-[0-9a-f-]{36}$/i.test(result.id) || typeof result.submittedAt !== 'string' ||
          Number.isNaN(Date.parse(result.submittedAt))) {
        const detail = result?.code === 'FORM_NOT_CONFIGURED'
          ? 'Online submission is not configured yet.'
          : result?.code === 'INVALID_FIELDS'
          ? 'Please check the contact details and required fields.'
          : 'Delivery could not be confirmed. Please check with us before submitting again.';
        throw new Error(detail);
      }
      setSubmittedTicket({
        ...fields, id: result.id, submittedAt: result.submittedAt, status: 'Received',
      });
    } catch (error) {
      const detail = error instanceof Error && error.name !== 'AbortError'
        ? error.message : 'Delivery could not be confirmed. Please check with us before submitting again.';
      window.alert(detail + ' Your form details have been kept. Contact ' + COMPANY_INFO.email + '.');
    } finally {
      window.clearTimeout(timeout);
      setIsSubmitting(false);
    }
  };

  const handleCopyTicket = () => {
    if (!submittedTicket) return;
    const text = `Mint Response Service Request Ticket:
Reference: ${submittedTicket.id}
Business: ${submittedTicket.businessName}
Contact: ${submittedTicket.fullName} (${submittedTicket.phone})
Service: ${submittedTicket.primaryService.toUpperCase()}
Urgency: ${submittedTicket.urgency.toUpperCase()}
Location: ${submittedTicket.locationCity}
Scope: ${submittedTicket.projectScope}`;

    navigator.clipboard.writeText(text);
    setCopiedTicket(true);
    setTimeout(() => setCopiedTicket(false), 2500);
  };

  const handleResetForm = () => {
    setSubmittedTicket(null);
    setProjectScope('');
  };

  return (
    <section id="contact" className="py-24 bg-slate-900 text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header (Exact Text from Prompt) */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 text-xs font-bold uppercase tracking-wider">
            Commercial Inquiries & Dispatch
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Contact Mint Response
          </h2>
          <p className="text-slate-300 text-base sm:text-lg">
            We are ready to assist with your commercial facility maintenance and improvement needs.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Contact Info Card (Exact Information from Prompt) */}
          <div className="lg:col-span-5 space-y-8">
            <div className="bg-slate-800/90 rounded-2xl border border-slate-700 p-8 shadow-xl">
              <h3 className="font-display text-2xl font-bold text-white mb-2">
                Get in Touch
              </h3>
              <p className="text-slate-400 text-sm mb-6">
                Connect directly with our facility response coordinators.
              </p>

              {/* Direct Details */}
              <div className="space-y-6">
                
                {/* Location */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/25 text-emerald-300 flex items-center justify-center shrink-0 shadow-xs shadow-emerald-500/20">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Headquarters</h4>
                    <p className="text-base font-semibold text-white mt-0.5">Mint Response</p>
                    <p className="text-sm text-slate-300">{COMPANY_INFO.location}</p>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/25 text-emerald-300 flex items-center justify-center shrink-0 shadow-xs shadow-emerald-500/20">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Phone</h4>
                    <a
                      href={`tel:${COMPANY_INFO.phoneHref}`}
                      className="text-base font-bold text-emerald-400 hover:text-emerald-300 transition-colors block mt-0.5"
                    >
                      {COMPANY_INFO.phonePlaceholder}
                    </a>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/25 text-emerald-300 flex items-center justify-center shrink-0 shadow-xs shadow-emerald-500/20">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Email</h4>
                    <a
                      href={`mailto:${COMPANY_INFO.email}`}
                      className="text-base font-medium text-white hover:text-emerald-300 transition-colors block mt-0.5"
                    >
                      {COMPANY_INFO.email}
                    </a>
                  </div>
                </div>

                {/* Business Hours */}
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/25 text-emerald-300 flex items-center justify-center shrink-0 shadow-xs shadow-emerald-500/20">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Business Hours</h4>
                    <p className="text-base font-semibold text-white mt-0.5">
                      {COMPANY_INFO.businessHours}
                    </p>
                    <div className="mt-2 p-2.5 rounded-md bg-amber-500/15 border border-amber-500/30 flex items-start gap-2">
                      <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <p className="text-xs text-amber-300 font-medium">
                        {COMPANY_INFO.emergencyNotice}
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            </div>

            {/* Fast Response Guarantee Box */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-950/70 to-slate-800 border border-emerald-500/40 shadow-lg">
              <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-300 mb-1">
                Our Commitment
              </h4>
              <p className="text-xl font-black text-white">
                {COMPANY_INFO.motto}
              </p>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Every request submitted receives swift acknowledgement and assignment to a dedicated commercial coordinator.
              </p>
            </div>
          </div>

          {/* Right Column: Request a Service Form */}
          <div className="lg:col-span-7">
            <div className="bg-white text-slate-900 rounded-2xl border border-slate-200 p-8 sm:p-10 shadow-2xl">
              
              {/* Form Header with Mint Logo */}
              <div className="mb-8 pb-6 border-b border-slate-200">
                <div className="flex items-center justify-between gap-4 flex-wrap mb-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 border border-emerald-300/60 px-3 py-1 rounded-md">
                    Direct Commercial Work Order / Quote
                  </span>
                  <MintLogo variant="horizontal" size="md" showSubtitle={false} />
                </div>
                <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
                  Request a Service
                </h3>
                <p className="text-slate-600 text-sm mt-2 leading-relaxed">
                  Need HVAC, plumbing, electrical, handyman, or renovation support for your commercial property? Contact Mint Response today to discuss your project and receive a customized service solution.
                </p>
              </div>

              {submittedTicket ? (
                /* Ticket Confirmation Receipt */
                <div className="space-y-6 animate-in fade-in zoom-in-95 duration-200">
                  <div className="p-6 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 space-y-3">
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-8 h-8 text-emerald-600 shrink-0" />
                        <div>
                          <h4 className="text-lg font-bold text-emerald-900">
                            Commercial Service Request Received!
                          </h4>
                          <p className="text-xs text-emerald-700">
                            Ticket Reference Number: <strong className="font-mono text-emerald-900">{submittedTicket.id}</strong>
                          </p>
                        </div>
                      </div>
                      <div className="bg-white p-2.5 rounded-xl border border-emerald-300 shadow-xs">
                        <MintLogo variant="icon" size="md" />
                      </div>
                    </div>
                    <p className="text-sm text-emerald-800 leading-relaxed pt-2 border-t border-emerald-200">
                      Thank you, <strong>{submittedTicket.fullName}</strong>. Our operations desk has logged your request for <strong>{submittedTicket.businessName}</strong>. A coordinator is reviewing your scope.
                    </p>
                  </div>

                  {/* Summary Details */}
                  <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 text-xs space-y-2.5">
                    <div className="flex justify-between py-1 border-b border-slate-200">
                      <span className="text-slate-500 font-medium">Trade Selected:</span>
                      <span className="font-bold text-slate-900 uppercase">{submittedTicket.primaryService}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200">
                      <span className="text-slate-500 font-medium">Facility Type:</span>
                      <span className="font-bold text-slate-900">{submittedTicket.propertyType}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200">
                      <span className="text-slate-500 font-medium">Urgency:</span>
                      <span className={`font-bold uppercase ${
                        submittedTicket.urgency === 'emergency' 
                          ? 'text-red-600' 
                          : submittedTicket.urgency === 'urgent' 
                          ? 'text-amber-600' 
                          : 'text-emerald-700'
                      }`}>
                        {submittedTicket.urgency}
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200">
                      <span className="text-slate-500 font-medium">City / Location:</span>
                      <span className="font-bold text-slate-900">{submittedTicket.locationCity}</span>
                    </div>
                    <div className="py-1">
                      <span className="text-slate-500 font-medium block mb-1">Project Scope:</span>
                      <p className="text-slate-800 bg-white p-2.5 rounded border border-slate-200 italic font-normal">
                        "{submittedTicket.projectScope}"
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      onClick={handleCopyTicket}
                      className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedTicket ? 'Details Copied!' : 'Copy Ticket Details'}</span>
                    </button>
                    <button
                      onClick={handleResetForm}
                      className="inline-flex items-center justify-center gap-2 py-3 px-4 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Submit Another Work Order
                    </button>
                  </div>
                </div>
              ) : (
                /* Service Request Form */
                <form onSubmit={handleSubmit} className="space-y-6">
                  <input type="text" name="companyWebsite" hidden tabIndex={-1} autoComplete="off"
                    value={companyWebsite} onChange={(e) => setCompanyWebsite(e.target.value)} />
                  
                  {/* Service Category & Urgency */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Required Service *
                      </label>
                      <select
                        value={primaryService}
                        onChange={(e) => setPrimaryService(e.target.value as ServiceCategory)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      >
                        <option value="hvac">HVAC Services</option>
                        <option value="plumbing">Commercial Plumbing</option>
                        <option value="electrical">Electrical Services</option>
                        <option value="handyman">Handyman Services</option>
                        <option value="renovation">Commercial Renovations (Interior)</option>
                        <option value="comprehensive">Comprehensive / Multi-Trade</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Response Priority *
                      </label>
                      <select
                        value={urgency}
                        onChange={(e) => setUrgency(e.target.value as UrgencyLevel)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      >
                        <option value="urgent">Urgent Commercial Need (24–48 Hours)</option>
                        <option value="emergency">Emergency Dispatch Request</option>
                        <option value="scheduled">Scheduled Project / Preventive Maintenance</option>
                      </select>
                    </div>
                  </div>

                  {/* Commercial Facility Type & Location */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Commercial Facility Type *
                      </label>
                      <select
                        value={propertyType}
                        onChange={(e) => setPropertyType(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      >
                        {INDUSTRIES_SERVED.map((ind) => (
                          <option key={ind.name} value={ind.name}>
                            {ind.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        City or Region
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. city or metro area"
                        value={locationCity}
                        onChange={(e) => setLocationCity(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  {/* Contact Person & Business Name */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Contact Name *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. John Miller, Facility Manager"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Company / Property Name *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Apex Office Center LLC"
                        value={businessName}
                        onChange={(e) => setBusinessName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Phone & Email */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        placeholder="(xxx) xxx-xxxx"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Work Email *
                      </label>
                      <input
                        type="email"
                        placeholder="name@company.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Scope Description */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Scope of Work or Maintenance Issue *
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Please describe the equipment, repair needed, or renovation goals (e.g. RTU troubleshooting, drywall patching after plumbing repair, tenant office repaint)..."
                      value={projectScope}
                      onChange={(e) => setProjectScope(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      required
                    ></textarea>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Note: Renovations and interior improvements only. We do not provide excavation services.
                    </p>
                  </div>

                  {/* Submit CTA */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 px-6 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-base shadow-xl shadow-emerald-500/30 hover:shadow-emerald-500/50 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99] disabled:opacity-75"
                  >
                    {isSubmitting ? (
                      <span>Dispatching Request...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Submit Service Request</span>
                      </>
                    )}
                  </button>

                  <p className="text-center text-xs text-slate-500">
                    Fast Response • Professional Service • Reliable Results
                  </p>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root = new URL('../', import.meta.url);
const read = (name) => readFileSync(new URL(name, root), 'utf8');

test('preserves protected original files byte-for-byte, including CSS and SVGs', () => {
  const hashes = JSON.parse(read('docs/preserved-file-hashes.json'));
  for (const [name, hash] of Object.entries(hashes)) {
    assert.equal(createHash('sha256').update(readFileSync(new URL(name, root))).digest('hex'), hash, name);
  }
});
test('applies the requested hero and header edits without replacing the headline', () => {
  const hero = read('src/components/Hero.tsx');
  assert.ok(hero.includes('Your Trusted Commercial Facility Management Partner'));
  for (const text of ['Kansas, USA', 'Facility Matrix', 'Trades Under One Roof', 'Statewide Coverage']) assert.ok(!hero.includes(text), text);
  assert.ok(!read('src/components/Navbar.tsx').includes('Kansas Commercial'));
  assert.ok(!read('src/components/MintLogo.tsx').includes(' • Kansas'));
});
test('applies the requested welcome removals and literal Why Us deletion', () => {
  const welcome = read('src/components/WelcomeSection.tsx');
  assert.ok(!welcome.includes('Headquartered in Kansas'));
  assert.ok(!welcome.includes('Regional Commercial Care'));
  assert.ok(welcome.includes('Fast Response'));
  assert.ok(read('src/components/WhyChooseUs.tsx').includes('pain points commercial property managers.'));
});
test('removes only the marked renovations card and its filter, retaining the original grid classes', () => {
  const services = read('src/components/ServicesSection.tsx');
  assert.ok(services.includes("CORE_SERVICES.filter(s => s.id !== 'renovation')"));
  assert.ok(services.includes('All {visibleServices.length} Core Services'));
  assert.ok(services.includes('lg:grid-cols-3'));
  assert.ok(read('src/components/Hero.tsx').includes('Commercial Renovations'));
  assert.ok(read('src/components/ContactAndRequestSection.tsx').includes('Commercial Renovations (Interior)'));
});
test('applies specified about, coverage and portfolio edits', () => {
  const about = read('src/components/AboutSection.tsx');
  assert.ok(about.includes('operating through Arkansas, Texas, Florida.'));
  assert.ok(!about.includes('Commercial Service Regions Across Kansas'));
  assert.ok(read('src/data/facilityData.ts').includes('Mint Response is an Arkansas-based facility management'));
  assert.ok(!read('src/components/IndustriesSection.tsx').includes('Manage Multiple Commercial Properties in Kansas?'));
});
test('uses the requested headquarters/hours and removes only selected contact labels', () => {
  const data = read('src/data/facilityData.ts'); const contact = read('src/components/ContactAndRequestSection.tsx');
  assert.ok(data.includes("location: 'Centerton, AR'"));
  assert.ok(data.includes('Monday – Sunday 8 am to 5 pm CT'));
  for (const text of ['{COMPANY_INFO.stateCoverage}', 'Direct Commercial Line', 'Bid requests & work orders']) assert.ok(!contact.includes(text));
});
test('uses Mint Response without LLC in public copy and omits the header phone', () => {
  const navbar = read('src/components/Navbar.tsx');
  assert.ok(!navbar.includes('phonePlaceholder'));
  assert.ok(!navbar.includes('Mint Response LLC'));
  assert.ok(!read('src/data/facilityData.ts').includes('Mint Response LLC'));
  assert.ok(!read('src/components/MintLogo.tsx').includes('>LLC<'));
  assert.ok(read('index.html').includes('Mint Response |'));
  assert.ok(!read('index.html').includes('Mint Response LLC'));
});
test('removes remaining Kansas copy and uses the owner-provided contact phone', () => {
  const publicFiles = [
    'index.html',
    'src/data/facilityData.ts',
    'src/components/AboutSection.tsx',
    'src/components/WhyChooseUs.tsx',
    'src/components/IndustriesSection.tsx',
    'src/components/ContactAndRequestSection.tsx',
    'src/components/Footer.tsx',
    'src/components/CommercialMaintenancePlanner.tsx',
    'src/components/Hero.tsx',
  ];
  for (const name of publicFiles) {
    assert.ok(!read(name).includes('Kansas'), name);
  }
  assert.ok(!read('src/data/facilityData.ts').includes('KANSAS_SERVICE_HUBS'));
  assert.ok(read('src/data/facilityData.ts').includes("phonePlaceholder: '479-341-5787'"));
  assert.ok(read('src/components/Footer.tsx').includes('{COMPANY_INFO.phonePlaceholder}'));
});
test('removes the footer renovations note at the bottom of the page', () => {
  const footer = read('src/components/Footer.tsx');
  assert.ok(!footer.includes('Note: We perform commercial renovations and interior improvements only.'));
  assert.ok(!footer.includes('We do not provide excavation services.'));
  assert.ok(footer.includes('All rights reserved.'));
});
test('removes browser-only ticket storage and waits for the real endpoint', () => {
  const contact = read('src/components/ContactAndRequestSection.tsx');
  assert.ok(!contact.includes('localStorage'));
  assert.ok(!contact.includes('Math.random'));
  assert.ok(contact.includes("fetch('/api/service-request'"));
  assert.ok(contact.includes("result?.ok !== true"));
  assert.ok(contact.includes('INDUSTRIES_SERVED[0].name'));
});

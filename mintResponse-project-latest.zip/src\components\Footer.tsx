import React from 'react';
import { Phone, Mail, Clock, MapPin, ArrowUp, ChevronRight } from 'lucide-react';
import { COMPANY_INFO, CORE_SERVICES, INDUSTRIES_SERVED } from '../data/facilityData';
import { MintLogo } from './MintLogo';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          
          {/* Brand Info & Mission Column */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center">
              <MintLogo variant="horizontal" theme="dark" size="lg" />
            </div>

            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              {COMPANY_INFO.heroDescription}
            </p>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs space-y-1">
              <p className="font-bold text-emerald-300">"{COMPANY_INFO.goalStatement}"</p>
              <p className="text-slate-400">{COMPANY_INFO.motto}</p>
            </div>
          </div>

          {/* Core Services Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Core Services
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              {CORE_SERVICES.map((s) => (
                <li key={s.id}>
                  <a
                    href="/#services"
                    className="hover:text-emerald-300 transition-colors inline-flex items-center gap-1 group"
                  >
                    <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-emerald-400" />
                    <span>{s.title}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Industries Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Industries Served
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              {INDUSTRIES_SERVED.slice(0, 6).map((ind) => (
                <li key={ind.name}>
                  <a
                    href="/#industries"
                    className="hover:text-emerald-300 transition-colors inline-flex items-center gap-1 group truncate max-w-[200px]"
                  >
                    <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-emerald-400 shrink-0" />
                    <span className="truncate">{ind.name}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Direct Contact Column */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Headquarters
            </h4>
            <div className="space-y-2.5 text-xs text-slate-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{COMPANY_INFO.location}</span>
              </p>
              <p className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <a href={`tel:${COMPANY_INFO.phoneHref}`} className="hover:text-white font-semibold">
                  {COMPANY_INFO.phoneDisplay}
                </a>
              </p>
              <p className="flex items-start gap-2">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <a href={`mailto:${COMPANY_INFO.email}`} className="hover:text-white">
                  {COMPANY_INFO.email}
                </a>
              </p>
              <p className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{COMPANY_INFO.businessHours}</span>
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar with Disclaimers & Top Button */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            <p>© {new Date().getFullYear()} Mint Response. All rights reserved.</p>
          </div>

          <button
            onClick={scrollToTop}
            className="inline-flex items-center gap-1.5 text-slate-400 hover:text-emerald-400 p-2 rounded-lg bg-slate-900 border border-slate-800 transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};

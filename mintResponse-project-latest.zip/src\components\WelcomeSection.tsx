import React from 'react';
import { Building, ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react';
import { COMPANY_INFO } from '../data/facilityData';

interface WelcomeSectionProps {
  onLearnMoreServices: () => void;
}

export const WelcomeSection: React.FC<WelcomeSectionProps> = ({ onLearnMoreServices }) => {
  return (
    <section className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Visual Architecture Frame */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="relative">
              <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white p-8 sm:p-10 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 transform translate-x-8 -translate-y-8 w-44 h-44 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none"></div>
                
                <div className="w-12 h-12 rounded-xl bg-emerald-500/25 border border-emerald-500/40 text-emerald-300 flex items-center justify-center mb-6 shadow-xs shadow-emerald-500/20">
                  <Building className="w-6 h-6" />
                </div>

                <h3 className="font-display text-2xl font-bold text-white mb-4">
                  100% Dedicated to Commercial Properties
                </h3>

                <p className="text-slate-300 text-sm leading-relaxed mb-6">
                  Unlike residential handymen who juggle small home tasks, Mint Response operates with dedicated commercial protocols, OSHA safety compliance, and property manager reporting standards.
                </p>

                <div className="space-y-3 pt-4 border-t border-slate-700/80">
                  <div className="flex items-center gap-2.5 text-xs text-slate-200 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Minimized operational downtime for your tenants</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-200 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Transparent commercial documentation & invoice clarity</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-slate-200 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Multi-trade scheduling under one master service partner</span>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-slate-700/60 flex items-center justify-between text-xs">
                  <span className="font-extrabold text-emerald-300 uppercase tracking-wider">Fast Response</span>
                </div>
              </div>

            </div>
          </div>

          {/* Right Text Content (Exact User Prompts) */}
          <div className="lg:col-span-7 order-1 lg:order-2 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300/60 text-xs font-bold tracking-wide uppercase">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Commercial Excellence</span>
            </div>

            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {COMPANY_INFO.welcomeTitle}
            </h2>

            <div className="space-y-4 text-slate-600 text-base sm:text-lg leading-relaxed">
              <p>
                {COMPANY_INFO.welcomeParagraph1}
              </p>
              <p className="text-slate-700 font-medium">
                {COMPANY_INFO.welcomeParagraph2}
              </p>
            </div>

            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={onLearnMoreServices}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors cursor-pointer"
              >
                <span>Learn More About Our Services</span>
                <ArrowRight className="w-4 h-4 text-emerald-400" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
